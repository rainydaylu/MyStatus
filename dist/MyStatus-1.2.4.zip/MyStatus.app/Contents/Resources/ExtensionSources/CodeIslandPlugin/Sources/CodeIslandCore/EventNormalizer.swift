import Foundation

public enum EventNormalizer {
    /// Normalize event names from various CLIs to internal PascalCase names
    public static func normalize(_ name: String) -> String {
        switch name {
        // Cursor (camelCase)
        case "beforeSubmitPrompt":    return "UserPromptSubmit"
        case "beforeShellExecution":  return "PreToolUse"
        case "afterShellExecution":   return "PostToolUse"
        case "beforeReadFile":        return "PreToolUse"
        case "afterFileEdit":         return "PostToolUse"
        case "beforeMCPExecution":    return "PreToolUse"
        case "afterMCPExecution":     return "PostToolUse"
        case "afterAgentThought":     return "Notification"
        case "afterAgentResponse":    return "AfterAgentResponse"
        case "stop":                  return "Stop"
        // Gemini
        case "BeforeTool":            return "PermissionRequest"
        case "AfterTool":             return "PostToolUse"
        case "BeforeAgent":           return "SubagentStart"
        case "AfterAgent":            return "SubagentStop"
        // GitHub Copilot CLI
        case "sessionStart":          return "SessionStart"
        case "sessionEnd":            return "SessionEnd"
        case "userPromptSubmitted":   return "UserPromptSubmit"
        case "preToolUse":            return "PreToolUse"
        case "postToolUse":           return "PostToolUse"
        case "errorOccurred":         return "Notification"
        // Kiro CLI (camelCase, agent-scoped)
        case "agentSpawn":            return "SessionStart"
        case "userPromptSubmit":      return "UserPromptSubmit"
        // Traecli (snake_case)
        case "session_start":         return "SessionStart"
        case "session_end":           return "SessionEnd"
        case "user_prompt_submit":    return "UserPromptSubmit"
        case "pre_tool_use":          return "PreToolUse"
        case "post_tool_use":         return "PostToolUse"
        case "post_tool_use_failure": return "PostToolUseFailure"
        case "permission_request":    return "PermissionRequest"
        case "permission_denied":     return "PermissionDenied"
        // Grok emits StopFailure when a turn ends on an API error. It is still
        // terminal for Island state, so fold both wire spellings onto Stop.
        case "stop_failure", "StopFailure": return "Stop"
        case "subagent_start":        return "SubagentStart"
        case "subagent_stop":         return "SubagentStop"
        case "pre_compact":           return "PreCompact"
        case "post_compact":          return "PostCompact"
        case "notification":          return "Notification"
        // Hermes (Nous Research) — snake_case but diverged from Claude/Gemini (#226).
        // `subagent_stop` already maps to SubagentStop in the traecli block above.
        case "pre_tool_call":         return "PreToolUse"
        case "post_tool_call":        return "PostToolUse"
        case "pre_llm_call":          return "UserPromptSubmit"
        // Both fire once per turn, from Hermes's turn finalizer
        // (agent/turn_finalizer.py): `post_llm_call` with the final reply when
        // there is one, then `on_session_end` whatever the outcome. Despite its
        // name, `on_session_end` is the end of a turn, not of the session —
        // mapping it to SessionEnd deleted the card after every reply (#364).
        // `post_llm_call` keeps its own name so a reply alone never pops a
        // completion: the Stop right behind it does that.
        case "post_llm_call":         return "AgentTurnSettled"
        case "on_session_start":      return "SessionStart"
        case "on_session_end":        return "Stop"
        // The real end of a session: `/new`, quitting the CLI, closing a
        // desktop / TUI session, the gateway's `/new` or shutdown — with the
        // id of the session that ended (hermes_cli/lifecycle.py).
        case "on_session_finalize":   return "SessionEnd"
        case "on_session_reset":      return "SessionEnd"
        // Cline (VSCode extension)
        case "TaskStart":             return "SessionStart"
        case "TaskResume":            return "UserPromptSubmit"
        case "TaskComplete":          return "TaskRoundComplete"
        case "TaskCancel":            return "TaskRoundComplete"
        default:                      return name
        }
    }
}

