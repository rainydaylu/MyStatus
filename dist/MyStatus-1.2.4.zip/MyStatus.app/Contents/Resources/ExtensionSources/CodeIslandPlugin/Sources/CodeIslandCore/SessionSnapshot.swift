import Foundation

public enum SessionTitleSource: String, Sendable, Codable {
    case codexThreadName
    case claudeCustomTitle
    case claudeAiTitle
}

public struct SessionSnapshot: Sendable {
    public static let customCLIConfigsKey = "custom_cli_configs_v1"

    public static let supportedSources: Set<String> = [
        "claude",
        "codex",
        "gemini",
        "cursor",
        "cursor-cli",
        "trae",
        "traecn",
        "traecli",
        "copilot",
        "qoder",
        "qoder-cli",
        "qoderwork",
        "droid",
        "codebuddy",
        "codybuddycn",
        "stepfun",
        "opencode",
        // MiMo Code (Xiaomi's OpenCode 1.x fork) and the Xiaomi MiMo desktop
        // app, which runs MiMo Code as its engine — one plugin feeds both.
        "mimo",
        "antigravity",
        "google-antigravity",
        "workbuddy",
        "hermes",
        "grok",
        "openclaw",
        "qwen",
        "kimi",
        "pi",
        "kiro",
        "cline",
        "dsh",
        "zcode",
        "aiwork",
        "aiwork-cli",
        "minimax",
    ]

    /// Sources whose tool/description text arrives as a rapid delta stream
    /// (AiWork/Agentix `stream.text_delta`). MorphText swaps text immediately for
    /// these instead of restarting its blur morph on every update, which would
    /// otherwise leave the label permanently unreadable. Scoped deliberately:
    /// every other source keeps the original morph behaviour.
    public static let rapidStreamingSources: Set<String> = [
        "aiwork",
        "aiwork-cli",
    ]

    public static let ideCompletionSources: Set<String> = [
        "cursor",
        "cursor-cli",
        "qoder",
        "qoder-cli",
        "trae",
        "traecn",
        "codebuddy",
        "codybuddycn",
    ]

    /// Desktop-IDE *host* sources. Their GUI host/helper processes (e.g.
    /// "Cursor Helper", "Trae Helper", the IDE's own `.../MacOS/<App>` binary)
    /// appear in the process ancestry of ANY CLI agent launched from that IDE's
    /// integrated terminal, and would be greedily matched by the loose
    /// `/<source>` substring rule in `CLIProcessResolver.sourceMatchesExecutablePath`.
    /// These must never be recovered via ancestry inference: a desktop IDE always
    /// reports itself explicitly through `--source`, or is detected via its
    /// dedicated `-cli` variant (`cursor-cli`, `qoder-cli`, `traecli`). Excluding
    /// them keeps e.g. Claude Code run inside Cursor's terminal — whose `claude`
    /// process is a source-less Node binary — from being mis-attributed to
    /// "cursor". (#220)
    public static let ideHostSources: Set<String> = [
        "cursor",
        "trae",
        "traecn",
        "qoder",
        "codebuddy",
        "codybuddycn",
        "stepfun",
        "antigravity",
        "google-antigravity",
    ]

    public var status: AgentStatus = .idle
    public var currentTool: String? {
        didSet { if currentTool != oldValue { currentToolUseId = nil } }
    }
    /// The tool use (its `tool_use_id`, or its source's spelling of it) that
    /// put up ``currentTool``, when it named one; any other change of
    /// ``currentTool`` forgets it. A tool step finishing another tool use
    /// leaves the running tool up (``finishesAnotherToolUse(_:)``).
    public var currentToolUseId: String?
    public var toolDescription: String?
    public var lastActivity: Date = Date()
    public var cwd: String?
    public var model: String?
    public var permissionMode: String?
    public var toolHistory: [ToolHistoryEntry] = []
    public var totalToolCallCount: Int = 0
    public var subagents: [String: SubagentState] = [:]
    /// Agent ids closed by SubagentStop/Stop/SessionEnd, in insertion order
    /// (newest last). Blocks merge/fold from putting a finished subagent back
    /// on the parent. Live growth is capped at ``maxClosedSubagentIds``;
    /// restored lists may be larger (see ``restoreClosedSubagentIds``).
    /// Mutate only via ``recordClosedSubagentId``, ``clearClosedSubagentId``,
    /// or ``restoreClosedSubagentIds`` so the live cap cannot be bypassed.
    public private(set) var closedSubagentIds: [String] = []
    /// O(1) membership mirror of ``closedSubagentIds`` for hot-path tombstone checks.
    private var closedSubagentIdSet: Set<String> = []
    /// Bound for *live* ``closedSubagentIds`` growth in long-lived Cursor sessions.
    /// Persist restore does not apply this cap (see ``restoreClosedSubagentIds``).
    public static let maxClosedSubagentIds = 256
    public var startTime: Date = Date()
    public var lastUserPrompt: String?
    public var lastAssistantMessage: String?
    /// Public assistant text emitted during the active Codex turn. This is
    /// transient UI state: a new turn clears it while chat history remains.
    public var liveCodexOutput: String?
    /// Absolute path to the JSONL transcript currently backing this session. Populated
    /// by hooks (`transcript_path` field) and by filesystem discovery, consumed by the
    /// JSONLTailer for incremental streaming of the latest assistant reply.
    public var transcriptPath: String?
    /// Cursor-only (#265): question text of an AskQuestion the IDE is currently
    /// blocked on. Cursor exposes no hook for its question tool, so this is a
    /// display-only wait — the user answers inside Cursor itself. Non-nil means
    /// a question is pending ("" = pending but text unknown). Set and cleared by
    /// transcript-tail detection; transient, never persisted.
    public var cursorPendingQuestion: String?
    /// Recent chat messages (max 3) for preview
    public var recentMessages: [ChatMessage] = []
    // Terminal info for window activation
    public var termApp: String?        // "iTerm.app", "Apple_Terminal", etc.
    public var itermSessionId: String?  // iTerm2 session ID for direct activation
    public var ttyPath: String?         // /dev/ttys00X
    public var kittyWindowId: String?   // Kitty window ID for precise focus
    public var tmuxPane: String?        // tmux pane identifier (%0, %1, etc.)
    public var tmuxClientTty: String?   // tmux client TTY for real terminal detection
    public var tmuxEnv: String?         // raw TMUX env var (socket info for non-default tmux server)
    public var termBundleId: String?    // __CFBundleIdentifier for precise terminal ID
    public var cmuxSurfaceId: String?   // cmux surface UUID (from CMUX_SURFACE_ID env var)
    public var cmuxWorkspaceId: String? // cmux workspace UUID (from CMUX_WORKSPACE_ID env var)
    public var zellijPaneId: String?    // Zellij pane id (numeric string) from ZELLIJ_PANE_ID env var
    public var zellijSessionName: String? // Zellij session name from ZELLIJ_SESSION_NAME env var
    public var weztermPaneId: String?   // WezTerm / Kaku pane id (numeric string) from WEZTERM_PANE env var
    public var herdrPaneId: String?       // Herdr pane identifier (wN:pN)
    public var herdrSocketPath: String?   // Owning Herdr server socket
    public var herdrBinaryPath: String?   // Herdr executable captured from pane env
    public var supersetWorkspaceId: String? // Superset workspace UUID (from SUPERSET_WORKSPACE_ID env var); presence means running inside Superset
    public var supersetPaneId: String?  // Superset pane/terminal id (from SUPERSET_PANE_ID / SUPERSET_TERMINAL_ID env var)
    /// Orca terminal handle (ORCA_TERMINAL_HANDLE) — the argument `orca terminal
    /// switch --terminal` takes, which is the only way to reach one specific
    /// worktree tab among several open for the same repo (#302).
    public var orcaTerminalHandle: String?
    /// Orca worktree id (ORCA_WORKTREE_ID). Presence alone identifies an Orca
    /// terminal even when Orca has stripped TERM_PROGRAM (it does that for
    /// Claude Agent Teams sessions), which is what used to send click-to-jump
    /// to a blank Terminal.app window.
    public var orcaWorktreeId: String?
    /// Claude Desktop's own id for a Code-tab session (`local_…`, from
    /// CLAUDE_CODE_HOST_SESSION_ID) — what its `claude://code/continue` link
    /// takes to open that exact session instead of just raising the app.
    public var claudeDesktopSessionId: String?
    public var cliPid: pid_t?            // CLI process PID (from bridge _ppid); this Mac's sessions only
    public var cliStartTime: Date?       // Start time of the tracked CLI PID (guards PID reuse)
    /// A remote session's agent process id on its own host (its hooks'
    /// `_ppid`). It names no process on this Mac, so it is never `cliPid`:
    /// only compared with other hooks from that host (`processId(onHost:)`).
    public var remotePid: pid_t?
    /// UI harness (T3 Code, …) that spawned the CLI, found by walking the
    /// ancestry of `cliPid`. Resolved off the main actor and re-read rather
    /// than persisted: the harness may have restarted between runs. (#321)
    public var hostHarness: HostHarness?
    public var source: String = "claude" // "claude" or "codex"
    public var interrupted: Bool = false
    /// The last turn ended on an error (Claude Code / Grok `StopFailure`, a
    /// failed AiWork stream or Cowork turn); the card's status reads ERROR
    /// until the next prompt. Set when AppState announces the turn's
    /// completion (`AttentionDecision.completion`). Transient.
    public var lastTurnFailed: Bool = false
    /// Cline-specific: true after TaskComplete/TaskCancel until the next TaskStart/TaskResume.
    /// Cline runs hooks asynchronously (background bridge), so events from prior tools can
    /// arrive after a TaskCancel and revive the session. This flag drops those stale events.
    public var taskRoundEnded: Bool = false
    public var sessionTitle: String?
    public var sessionTitleSource: SessionTitleSource?
    public var providerSessionId: String?
    /// The card of the session this one works for: a child session on a card
    /// of its own (``SubsessionLink`` — a Codex subagent thread, a Cursor
    /// Task, a pi-subagents child, …), as Agent Sub-Sessions routed it or the
    /// child declared it (`_parent_session_id`). Its turns are part of the
    /// parent's, so none of them rings, pops a completion card or sends a
    /// push; approvals and questions still do. Persisted.
    public var parentSessionId: String?
    /// AiWork/Agentix `client_type` from `sessions.get` (e.g. `DTCoderGUI`, `AiWorkGUI`).
    /// Prefer this over the `acp:`/`cli:` session-id prefix — modern TUI also uses `acp:`.
    public var aiworkClientType: String?
    public var remoteHostId: String?
    public var remoteHostName: String?
    /// Tools the user chose "Always allow … this session" for on a card whose
    /// agent keeps no rule for it — a remote Codex, whose rules live on its
    /// own host; a running Codex, which reads the rules and config.toml it
    /// is given only when a session starts. Its later requests for them are
    /// allowed without a card. Goes with the card — a SessionStart rebuilds
    /// it — and is never persisted.
    public var alwaysAllowedTools: Set<String> = []
    /// The same for the Codex prefix rules an "Always" of this session saved
    /// (the words its link named): a later command each of whose commands
    /// starts with one of them is allowed without a card.
    public var alwaysAllowedCommandPrefixes: Set<[String]> = []
    /// nil = unchecked, false = not YOLO, true = YOLO
    public var isYoloMode: Bool?
    /// Checked-out git branch for cwd; refreshed on cwd changes and Stop
    /// (a turn may have switched branches). nil for non-repo and remote cwds.
    public var gitBranch: String?
    public var gitIsWorktree: Bool = false
    /// The agent's own task checklist (TaskCreate/TaskUpdate, TodoWrite,
    /// Codex update_plan), fed by hooks here and by the transcript tailer.
    public var agentTasks = AgentTaskList()
    /// Claude Code's `away_summary` recap of an idle session; cleared by the
    /// next user prompt. See ``SessionRecap``.
    public var recap: SessionRecap?
    /// Reasoning effort of the latest turn ("xhigh", "max", …), read from the
    /// transcript next to the turn's model. Hooks don't report it.
    public var reasoningEffort: String?
    /// When a hook last reported `model`. An attach-time transcript backfill
    /// must not replace it with a model from an older line
    /// (`claude --resume --model X` over a transcript that ran on Y).
    public var modelReportedAt: Date?
    /// What the latest `/model` switch said about the 1M context variant; nil
    /// until one is seen. Transcript lines carry only the bare API id, so this
    /// is the one place a switch *to or from* the `[1m]` variant shows up.
    public var configuredLongContext: Bool?
    /// Hermes hooks reported this card's prompts (`pre_llm_call`) / replies
    /// (`post_llm_call`) themselves. Hooks are on time where Hermes's own store
    /// lags behind, so once they do, the store only supplies the title; see
    /// ``applyHermesStore(_:)``. Transient, never persisted.
    public var hermesHooksReportPrompts = false
    public var hermesHooksReportReplies = false
    /// The latest Hermes turn hook came from a conversation held away from
    /// this Mac (a gateway chat, the API server; see
    /// ``HermesHookPayload/isQuiet(_:)``). The process behind such a card is
    /// the gateway daemon, which outlives every chat it serves, so the idle
    /// card is swept like a hook-only one. Persisted: a restored card is
    /// bound to the daemon again.
    public var hermesChatElsewhere = false

    public init(startTime: Date = Date()) {
        self.startTime = startTime
    }

    /// Record a closed subagent/Task id (no-op if already present). Evicts the
    /// oldest entries when over ``maxClosedSubagentIds``.
    ///
    /// Callers must serialize access (today: `@MainActor` / main-queue session
    /// mutation). The check-then-append is not atomic across threads the way
    /// `Set.insert` was — do not call off the session-owning queue.
    public mutating func recordClosedSubagentId(_ id: String) {
        let trimmed = id.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !closedSubagentIdSet.contains(trimmed) else { return }
        closedSubagentIds.append(trimmed)
        closedSubagentIdSet.insert(trimmed)
        let overflow = closedSubagentIds.count - Self.maxClosedSubagentIds
        if overflow > 0 {
            for evicted in closedSubagentIds.prefix(overflow) {
                closedSubagentIdSet.remove(evicted)
            }
            closedSubagentIds.removeFirst(overflow)
        }
    }

    /// Drop a tombstone so the agent/Task may be folded or shown again.
    /// Trims like ``recordClosedSubagentId`` so whitespace-padded ids clear.
    public mutating func clearClosedSubagentId(_ id: String) {
        let trimmed = id.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        guard closedSubagentIdSet.remove(trimmed) != nil else { return }
        closedSubagentIds.removeAll { $0 == trimmed }
    }

    /// O(1) tombstone check used on the subagent hook hot path.
    /// Trims like ``recordClosedSubagentId`` / ``clearClosedSubagentId``.
    public func hasClosedSubagentId(_ id: String) -> Bool {
        let trimmed = id.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return false }
        return closedSubagentIdSet.contains(trimmed)
    }

    /// Restore persisted ids in file order **without** applying the live cap.
    ///
    /// Pre-cap builds wrote this array via `Set.sorted()` (lexicographic) — that
    /// order is not recency, so keep-last-N on restore would drop arbitrary
    /// tombstones and allow finished Tasks to re-fold. Disk size already bounds
    /// memory; ``recordClosedSubagentId`` still caps *new* live growth.
    public mutating func restoreClosedSubagentIds(_ ids: [String]) {
        closedSubagentIds = []
        closedSubagentIdSet = []
        closedSubagentIds.reserveCapacity(ids.count)
        closedSubagentIdSet.reserveCapacity(ids.count)
        for id in ids {
            let trimmed = id.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty, !closedSubagentIdSet.contains(trimmed) else { continue }
            closedSubagentIds.append(trimmed)
            closedSubagentIdSet.insert(trimmed)
        }
    }

    public static func normalizedSupportedSource(_ source: String?) -> String? {
        guard let source else { return nil }
        let normalized = source.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !normalized.isEmpty else { return nil }

        let aliases: [String: String] = [
            "factory": "droid",
            "ag": "antigravity",
            "anti-gravity": "antigravity",
            "anti gravity": "antigravity",
            // Google Antigravity (Gemini-based IDE/CLI). A SEPARATE product from
            // the "antigravity" Claude-Code fork above — it reads
            // ~/.gemini/config/hooks.json, not .antigravity/settings.json. Keep
            // the "ag"/"anti-gravity" aliases pointed at the fork; only these
            // explicit google-prefixed / -ide variants resolve here (#215).
            "googleantigravity": "google-antigravity",
            "google antigravity": "google-antigravity",
            "google-anti-gravity": "google-antigravity",
            "antigravity-ide": "google-antigravity",
            "antigravity-cli": "google-antigravity",
            "agy": "google-antigravity",
            "work-buddy": "workbuddy",
            "work body": "workbuddy",
            "work-body": "workbuddy",
            "workbody": "workbuddy",
            "hermes-agent": "hermes",
            "hermes-agents": "hermes",
            "hermes agent": "hermes",
            "hermes agents": "hermes",
            "grok-cli": "grok",
            "grokcli": "grok",
            "grok-build": "grok",
            "grok build": "grok",
            // OpenClaw (openclaw.ai) — personal-assistant Gateway daemon,
            // formerly branded Clawdbot. Keep the old name as an alias so
            // events from a not-yet-renamed install land on the same source.
            "open-claw": "openclaw",
            "open claw": "openclaw",
            "clawdbot": "openclaw",
            "qwen-code": "qwen",
            "qwencode": "qwen",
            "cursor-agent": "cursor-cli",
            "cursoragent": "cursor-cli",
            "cursorcli": "cursor-cli",
            "qodercli": "qoder-cli",
            // Qoder 国行 (China build): a separate `qoderclicn` binary rooted at
            // ~/.qoder-cn, but the same Claude-format hook contract as the
            // international CLI — so it shares the qoder-cli source (#289).
            "qoderclicn": "qoder-cli",
            "qodercli-cn": "qoder-cli",
            "qoder-cn": "qoder-cli",
            // AiWork (formerly DTCoder) — the pre-rename spelling and the
            // no-separator CLI variants normalise onto the `aiwork*` keys.
            "dtcoder": "aiwork",
            "dtcoder-cli": "aiwork-cli",
            "dtcodercli": "aiwork-cli",
            "aiworkcli": "aiwork-cli",
            "qodercn": "qoder-cli",
            // QoderWork — Qoder's standalone desktop assistant app (not the
            // IDE); own hooks file at ~/.qoderwork/settings.json (#249).
            "qoder-work": "qoderwork",
            "qoder work": "qoderwork",
            "kimi-cli": "kimi",
            "kimicli": "kimi",
            "kimi-code": "kimi",
            "kimicode": "kimi",
            "kimi_code": "kimi",
            "kimi-code-cli": "kimi",
            "kimicodecli": "kimi",
            "kimi_code_cli": "kimi",
            "kiro-cli": "kiro",
            "kirocli": "kiro",
            "codebuddycn": "codybuddycn",
            "codybuddy-cn": "codybuddycn",
            "step-fun": "stepfun",
            "step fun": "stepfun",
            "trae-cn": "traecn",
            "trae_cn": "traecn",
            "trae cn": "traecn",
            "traecli": "traecli",
            "omp": "pi",
            "oh-my-pi": "pi",
            "oh my pi": "pi",
            "z-code": "zcode",
            "z code": "zcode",
            // MiniMax Code CLI — the executable is `mcode` (npm @minimax-ai/code)
            // and the Node runtime renames the process title to `minimax-code`,
            // so both spellings (and the product name) normalize onto `minimax`.
            "mcode": "minimax",
            "minimax-code": "minimax",
            "minimaxcode": "minimax",
            "minimax-cli": "minimax",
            "minimaxcli": "minimax",
            "minimax-code-cli": "minimax",
            // MiMo Code (`mimo` CLI, npm @mimo-ai/cli) and the Xiaomi MiMo
            // desktop app share one source: the app's engine is MiMo Code.
            // No prefix rule — "mimo…" is too short a stem to claim.
            "mimocode": "mimo",
            "mimo-code": "mimo",
            "mimo_code": "mimo",
            "mimo code": "mimo",
            "mimo-cli": "mimo",
            "mimocli": "mimo",
            "mimo-desktop": "mimo",
            "mimodesktop": "mimo",
            "xiaomi-mimo": "mimo",
            "xiaomimimo": "mimo",
            "xiaomi mimo": "mimo",
            "xiaomi-mimo-ai": "mimo",
        ]
        let canonical = aliases[normalized] ?? normalized
        let dynamicSupportedSources = supportedSources.union(loadCustomSources())

        if dynamicSupportedSources.contains(canonical) { return canonical }
        // Match Google Antigravity variants BEFORE the bare "antigravity" prefix
        // clause below, so a "google-antigravity-*" sub-brand never falls through
        // to the Claude-fork source.
        if canonical.hasPrefix("google-antigravity") || canonical.hasPrefix("googleantigravity") { return "google-antigravity" }
        if canonical.hasPrefix("antigravity") { return "antigravity" }
        if canonical.hasPrefix("workbuddy") { return "workbuddy" }
        if canonical.hasPrefix("hermes") { return "hermes" }
        if canonical.hasPrefix("grok") { return "grok" }
        if canonical.hasPrefix("openclaw") { return "openclaw" }
        if canonical.hasPrefix("qwen") { return "qwen" }
        if canonical.hasPrefix("kiro") { return "kiro" }
        if canonical.hasPrefix("kimi") { return "kimi" }
        if canonical.hasPrefix("minimax") { return "minimax" }
        if canonical.hasPrefix("codybuddycn") || canonical.hasPrefix("codebuddycn") { return "codybuddycn" }
        if canonical.hasPrefix("stepfun") { return "stepfun" }
        if canonical.hasPrefix("traecn") { return "traecn" }
        if canonical.hasPrefix("traecli") { return "traecli" }
        if canonical.hasPrefix("trae") { return "trae" }
        return nil
    }

    private static func loadCustomSources() -> Set<String> {
        guard let data = UserDefaults.standard.data(forKey: customCLIConfigsKey),
              let raw = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
            return []
        }
        return Set(raw.compactMap { item in
            (item["source"] as? String)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .lowercased()
        }.filter { !$0.isEmpty })
    }

    private static func loadCustomSourceNames() -> [String: String] {
        guard let data = UserDefaults.standard.data(forKey: customCLIConfigsKey),
              let raw = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
            return [:]
        }
        var names: [String: String] = [:]
        for item in raw {
            guard let source = (item["source"] as? String)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
                .lowercased(),
                  !source.isEmpty else { continue }
            let display = (item["name"] as? String)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            if let display, !display.isEmpty {
                names[source] = display
            }
        }
        return names
    }

    public var activeSubagentCount: Int {
        subagents.values.filter { $0.status != .idle }.count
    }

    public mutating func addRecentMessage(_ msg: ChatMessage, maxCount: Int = 3) {
        recentMessages.append(msg)
        if recentMessages.count > maxCount {
            recentMessages.removeFirst(recentMessages.count - maxCount)
        }
    }

    public mutating func insertRecentMessage(_ msg: ChatMessage, at index: Int, maxCount: Int = 3) {
        recentMessages.insert(msg, at: index)
        if recentMessages.count > maxCount {
            recentMessages.removeFirst(recentMessages.count - maxCount)
        }
    }

    public mutating func recordTool(_ tool: String, description: String?, success: Bool, agentType: String?, maxHistory: Int) {
        totalToolCallCount += 1
        let entry = ToolHistoryEntry(tool: tool, description: description, timestamp: Date(), success: success, agentType: agentType)
        toolHistory.append(entry)
        if toolHistory.count > maxHistory {
            toolHistory.removeFirst()
        }
    }

    /// Whether a PostToolUse / PostToolUseFailure finishes a tool use other
    /// than the one running. Remote tool steps do not wait for the island,
    /// so over SSH a large PostToolUse(A) can arrive after the PreToolUse(B)
    /// that came next — with parallel tool calls in particular. Only when
    /// both name their tool use: a source that names none goes as before.
    public func finishesAnotherToolUse(_ event: HookEvent) -> Bool {
        Self.isStep(event, ofAnotherToolUseThan: currentToolUseId, showing: currentTool)
    }

    static func isStep(_ event: HookEvent, ofAnotherToolUseThan running: String?, showing tool: String?) -> Bool {
        guard tool != nil, let running, let finished = event.toolUseId else { return false }
        return finished != running
    }

    /// Display name: project folder, or short session ID
    public var displayName: String {
        guard let cwd = cwd else { return "Session" }
        return Self.resolvedProjectDisplayName(from: cwd)
    }

    /// Directory names that are agent metadata, not user projects. Only these
    /// exact dot-dirs are peeled / treated as unhelpful — legitimate dot-named
    /// repos (.dotfiles, .config, .emacs.d) must keep their own name.
    static let agentMetadataDirNames: Set<String> = [
        ".claude", ".cursor", ".codex", ".gemini", ".qoder", ".qoder-cn", ".qoderwork",
        ".trae", ".trae-cn", ".kiro", ".copilot", ".factory", ".codebuddy",
        ".codybuddycn", ".stepfun", ".workbuddy", ".hermes", ".kimi", ".kimi-code",
        ".grok", ".pi", ".omp", ".qwen", ".zcode", ".openclaw", ".codeisland",
    ]

    /// Resolve a human project folder label from a cwd path.
    static func resolvedProjectDisplayName(from cwd: String) -> String {
        var name = displayNameLeafFromCursorProjectsPath(cwd)
            ?? (cwd as NSString).lastPathComponent

        // Agent metadata dirs (.claude, .cursor) are not project names (#248).
        if Self.agentMetadataDirNames.contains(name) {
            if let peeled = peelProjectNameBeforeMetadataDir(in: cwd, leaf: name) {
                name = peeled
            } else if isUnhelpfulHookCwd(cwd) {
                return "Session"
            }
        }

        if isHomeDirectoryPath(cwd) || isHomeDirectoryBasename(name, for: cwd) {
            return "Session"
        }

        if name.count >= 8 && name.allSatisfy(\.isNumber) {
            let parent = ((cwd as NSString).deletingLastPathComponent as NSString).lastPathComponent
            if !parent.isEmpty && parent != "/" && !isHomeDirectoryBasename(parent, for: cwd) {
                return parent
            }
        }
        return name
    }

    /// Cursor stores projects under `~/.cursor/projects/<encoded>/…` where slashes
    /// in the original workspace path become hyphens. Literal hyphens inside a
    /// folder name are preserved, so naive full-path reversal is ambiguous — walk
    /// hyphen segments from the right until the reconstructed path exists.
    /// Decode results are memoized: displayName is evaluated on every SwiftUI
    /// render of every session card, and the walk below stats the filesystem.
    /// NSCache is thread-safe and evicts under memory pressure.
    private static let cursorLeafCache = NSCache<NSString, NSString>()

    /// The stat behind that walk. Tests describe the folders they need here
    /// instead of creating them in the user's real home — the old tests made
    /// and then recursively deleted `~/myproject` and `~/my-sample-app`.
    static var cursorProjectFolderExists: (String) -> Bool = { path in
        FileManager.default.fileExists(atPath: path)
    }

    static func displayNameLeafFromCursorProjectsPath(_ cwd: String) -> String? {
        if let cached = cursorLeafCache.object(forKey: cwd as NSString) {
            return cached.length == 0 ? nil : (cached as String)
        }
        let result = computeDisplayNameLeafFromCursorProjectsPath(cwd)
        cursorLeafCache.setObject((result ?? "") as NSString, forKey: cwd as NSString)
        return result
    }

    private static func computeDisplayNameLeafFromCursorProjectsPath(_ cwd: String) -> String? {
        let marker = "/.cursor/projects/"
        guard let range = cwd.range(of: marker) else { return nil }
        let encoded = cwd[range.upperBound...].split(separator: "/").first.map(String.init) ?? ""
        guard !encoded.isEmpty else { return nil }

        let homeEncoded = homeDirectoryProjectEncoded()
        let projectEncoded: String
        if encoded.hasPrefix(homeEncoded + "-") {
            projectEncoded = String(encoded.dropFirst(homeEncoded.count + 1))
        } else if encoded == homeEncoded {
            return nil
        } else {
            projectEncoded = encoded
        }
        guard !projectEncoded.isEmpty else { return nil }

        let parts = projectEncoded.split(separator: "-", omittingEmptySubsequences: false).map(String.init)
        guard !parts.isEmpty else { return nil }

        let home = FileManager.default.homeDirectoryForCurrentUser.path
        // Prefer the longest leaf whose prefix reconstructs to a real directory.
        for k in stride(from: parts.count - 1, through: 0, by: -1) {
            let leaf = parts[k...].joined(separator: "-")
            guard !leaf.isEmpty else { continue }
            if k == 0 {
                return leaf
            }
            let relative = parts[..<k].joined(separator: "/") + "/" + leaf
            if cursorProjectFolderExists("\(home)/\(relative)") {
                return leaf
            }
        }
        return parts.last
    }

    /// When cwd sits inside a metadata dir, or a Cursor-encoded leaf is one, peel
    /// back to the real project folder name.
    static func peelProjectNameBeforeMetadataDir(in cwd: String, leaf: String) -> String? {
        guard Self.agentMetadataDirNames.contains(leaf) else { return nil }

        if cwd.contains("/.cursor/projects/") {
            let marker = "/.cursor/projects/"
            guard let range = cwd.range(of: marker) else { return nil }
            let encoded = cwd[range.upperBound...].split(separator: "/").first.map(String.init) ?? ""
            if let peeled = peelEncodedProjectTailBeforeMetadataDir(encoded) {
                return peeled
            }
        }

        let parent = ((cwd as NSString).deletingLastPathComponent as NSString).lastPathComponent
        let parentPath = (cwd as NSString).deletingLastPathComponent
        if !parent.isEmpty && parent != "/",
           !isHomeDirectoryPath(parentPath),
           !parent.contains("/.cursor/projects/"),
           !looksLikeCursorEncodedDir(parent) {
            return parent
        }
        return nil
    }

    /// Hook/bridge cwd values that carry no project identity — getcwd() inside
    /// `~/.claude` or at `$HOME` must not block workspace_roots / transcript_path.
    static func isUnhelpfulHookCwd(_ cwd: String) -> Bool {
        if isHomeDirectoryPath(cwd) { return true }
        let last = (cwd as NSString).lastPathComponent
        guard Self.agentMetadataDirNames.contains(last) else { return false }
        return isHomeDirectoryPath((cwd as NSString).deletingLastPathComponent)
    }

    static func isHomeDirectoryPath(_ path: String) -> Bool {
        let home = (FileManager.default.homeDirectoryForCurrentUser.path as NSString).standardizingPath
        return (path as NSString).standardizingPath == home
    }

    static func isHomeDirectoryBasename(_ name: String, for cwd: String) -> Bool {
        name == (FileManager.default.homeDirectoryForCurrentUser.path as NSString).lastPathComponent
            && (isHomeDirectoryPath(cwd) || isUnhelpfulHookCwd(cwd))
    }

    static func peelEncodedProjectTailBeforeMetadataDir(_ encoded: String) -> String? {
        let homeEncoded = homeDirectoryProjectEncoded()
        let projectEncoded: String
        if encoded.hasPrefix(homeEncoded + "-") {
            projectEncoded = String(encoded.dropFirst(homeEncoded.count + 1))
        } else {
            projectEncoded = encoded
        }
        let parts = projectEncoded.split(separator: "-", omittingEmptySubsequences: false).map(String.init)
        guard parts.count >= 2, let last = parts.last,
              Self.agentMetadataDirNames.contains(last) else { return nil }
        let peeled = parts[parts.count - 2]
        return peeled.isEmpty ? nil : peeled
    }

    private static func looksLikeCursorEncodedDir(_ name: String) -> Bool {
        name.contains("-") && !name.hasPrefix(".")
    }

    private static func homeDirectoryProjectEncoded() -> String {
        var home = FileManager.default.homeDirectoryForCurrentUser.path
        if home.hasPrefix("/") { home = String(home.dropFirst()) }
        return home.replacingOccurrences(of: "/", with: "-")
    }

    public func displayTitle(sessionId: String) -> String {
        sessionLabel ?? sessionId
    }

    public func displaySessionId(sessionId: String) -> String {
        if let providerSessionId {
            let trimmed = providerSessionId.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmed.isEmpty {
                return trimmed
            }
        }
        return sessionId
    }

    public var projectDisplayName: String {
        displayName
    }

    public var isRemote: Bool {
        guard let remoteHostId else { return false }
        return !remoteHostId.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    /// The agent's process id as hooks from `host` (nil: this Mac) report
    /// it — nil when the session runs on another machine, where the same
    /// number is a different process.
    public func processId(onHost host: String?) -> pid_t? {
        guard let host else { return isRemote ? nil : cliPid }
        return isRemote && remoteHostId == host ? remotePid : nil
    }

    public var remoteDisplayName: String? {
        guard let remoteHostName else { return nil }
        let trimmed = remoteHostName.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    public var sessionLabel: String? {
        guard let sessionTitle else { return nil }
        let trimmed = sessionTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    /// Shortened model name: "claude-opus-4-6" → "opus"
    public var shortModelName: String? {
        guard let model = model else { return nil }
        let lower = model.lowercased()
        if lower.contains("opus") { return "opus" }
        if lower.contains("sonnet") { return "sonnet" }
        if lower.contains("haiku") { return "haiku" }
        if lower.contains("gemini") { return "gemini" }
        if let last = model.split(separator: "-").last, last.count <= 8 {
            return String(last)
        }
        return String(model.prefix(8))
    }

    /// Source label for display
    public var sourceLabel: String {
        switch source {
        case "claude": return "Claude"
        case "codex": return "Codex"
        case "gemini": return "Gemini"
        case "cursor": return "Cursor"
        case "cursor-cli": return "Cursor CLI"
        case "trae": return "Trae"
        case "traecn": return "Trae CN"
        case "traecli": return "Traecli"
        case "qoder": return termBundleId == "com.qoder.ide" ? "Qoder IDE" : "Qoder"
        case "qoder-cli": return "Qoder CLI"
        case "qoderwork": return "QoderWork"
        case "droid": return "Factory"
        case "codebuddy": return "CodeBuddy"
        case "codybuddycn": return "CodyBuddyCN"
        case "stepfun": return "StepFun"
        case "opencode": return "OpenCode"
        case "mimo": return "MiMo"
        case "antigravity": return "AntiGravity"
        case "google-antigravity": return "Google Antigravity"
        case "workbuddy": return "WorkBuddy"
        case "hermes": return "Hermes"
        case "grok": return "Grok CLI"
        case "openclaw": return "OpenClaw"
        case "qwen": return "Qwen Code"
        case "kimi": return "Kimi Code CLI"
        case "pi": return "Pi"
        case "kiro": return "Kiro"
        case "cline": return "Cline"
        case "zcode": return "ZCode"
        case "aiwork": return "AiWork"
        case "aiwork-cli": return "AiWork CLI"
        case "minimax": return "MiniMax Code CLI"
        default:
            if let customName = Self.loadCustomSourceNames()[source] {
                return customName
            }
            return source.capitalized
        }
    }

    public var isCodex: Bool { source == "codex" }
    public var isClaude: Bool { source == "claude" }

    /// True when the session runs inside a native app in APP mode (Cursor agent, Codex APP, etc.)
    /// — the app IS the agent, not just a terminal hosting a CLI.
    /// Requires both bundle ID AND source to match (Claude CLI in Cursor terminal ≠ native app mode).
    public var isNativeAppMode: Bool {
        guard let bid = termBundleId else { return false }
        guard let expectedSource = Self.appBundleSources[bid] else { return false }
        return source == expectedSource
    }

    /// True when the session runs inside an IDE's integrated terminal.
    /// We can't query IDE tab/pane state, so notification suppression should be skipped.
    public var isIDETerminal: Bool {
        guard let bid = termBundleId else {
            // Zed rebuilds the environment it gives its integrated terminal, so
            // no __CFBundleIdentifier reaches the hook — TERM_PROGRAM is the only
            // signal left, and without this the session reads as a plain terminal
            // whose tab visibility we would wrongly claim to know (#307).
            return termApp?.lowercased() == "zed"
        }
        if isNativeAppMode { return false }
        // Known apps used as terminal (e.g., Claude CLI in Cursor's integrated terminal)
        if Self.appBundleNames[bid] != nil { return true }
        let lower = bid.lowercased()
        return lower.contains("vscode") || lower.contains("vscodium")
            || lower == "com.trae.app"
            || lower.contains("windsurf") || lower.contains("codeium")
            || lower.contains("jetbrains")
            || lower.contains("zed")
            || lower.contains("xcode") || lower == "com.apple.dt.xcode"
            || lower.contains("panic.nova")
            || lower.contains("android.studio")
            || lower.contains("antigravity")
    }

    /// Bundle IDs of native apps (not terminals)
    private static let appBundleNames: [String: String] = [
        "com.todesktop.230313mzl4w4u92": "Cursor",
        "com.trae.app": "Trae",
        "cn.trae.app": "Trae CN",
        "com.qoder.ide": "Qoder IDE",
        "com.qoder.app": "Qoder",
        "com.factory.app": "Factory",
        "com.tencent.codebuddy": "CodeBuddy",
        "com.tencent.codebuddy.cn": "CodyBuddyCN",
        "com.stepfun.app": "StepFun",
        "com.openai.codex": "Codex",
        "ai.opencode.desktop": "OpenCode",
        "com.google.antigravity": "Antigravity",
        // Claude Code Desktop (#211): local Code-tab sessions run the same engine
        // and fire the same ~/.claude/settings.json hooks as the CLI.
        "com.anthropic.claudefordesktop": "Claude",
        "com.alipay.dtcoder.ide": "AiWork",
        // Xiaomi MiMo desktop — mainland and overseas ("AI") editions are
        // separate installs with their own bundle ids.
        "com.xiaomi.mimo.desktop": "Xiaomi MiMo",
        "com.xiaomi.mimo.desktop-ai": "Xiaomi MiMo AI",
    ]

    /// Maps native app bundle IDs to their expected source identifier.
    /// Used by isNativeAppMode to distinguish "Cursor agent" from "Claude CLI in Cursor terminal".
    private static let appBundleSources: [String: String] = [
        "com.todesktop.230313mzl4w4u92": "cursor",
        "com.trae.app": "trae",
        // Trae CN ships as its own app (`Trae CN.app`), not inside Trae.app.
        "cn.trae.app": "traecn",
        "com.qoder.ide": "qoder",
        // Qoder App is separate from the IDE, but shares its ~/.qoder hooks.
        "com.qoder.app": "qoder",
        "com.factory.app": "droid",
        "com.tencent.codebuddy": "codebuddy",
        "com.tencent.codebuddy.cn": "codybuddycn",
        "com.stepfun.app": "stepfun",
        "com.openai.codex": "codex",
        "ai.opencode.desktop": "opencode",
        // Google Antigravity IDE — its integrated terminal launches the agy CLI,
        // whose hooks report --source google-antigravity (#215).
        "com.google.antigravity": "google-antigravity",
        // Claude Code Desktop (#211) — hook subprocesses inherit the app's
        // __CFBundleIdentifier, so desktop Code sessions arrive tagged with it.
        "com.anthropic.claudefordesktop": "claude",
        "com.alipay.dtcoder.ide": "aiwork",
        // Xiaomi MiMo desktop runs MiMo Code in its own main process, so the
        // plugin's events carry the app's __CFBundleIdentifier.
        "com.xiaomi.mimo.desktop": "mimo",
        "com.xiaomi.mimo.desktop-ai": "mimo",
    ]

    /// Source id for the native app that owns `bundleId`, if any.
    public static func sourceForAppBundleId(_ bundleId: String) -> String? {
        appBundleSources[bundleId]
    }

    /// Source used for the session-card mascot.
    ///
    /// Prefers the hook/discovery source. When that is missing, fall back to the
    /// native-app bundle map so a Cursor/Codex desktop session does not render
    /// as the default Claude mascot while the right-hand badge still says Cursor.
    public var mascotSource: String {
        if let normalized = Self.normalizedSupportedSource(source) {
            return normalized
        }
        if let bid = termBundleId, let inferred = Self.appBundleSources[bid] {
            return inferred
        }
        return source
    }

    /// True when this is a CLI agent hosted inside another IDE/app terminal
    /// (e.g. Claude Code inside Cursor) — mascot/badge should follow the CLI,
    /// not the host IDE brand.
    public var isCLIHostedInForeignApp: Bool {
        guard isIDETerminal,
              let src = Self.normalizedSupportedSource(source),
              let bid = termBundleId,
              let hostSource = Self.appBundleSources[bid] else {
            return false
        }
        return src != hostSource
    }

    /// Right-hand session badge text: CLI brand when hosted in a foreign IDE,
    /// otherwise the host terminal/app name.
    public var terminalBadgeLabel: String? {
        if isCLIHostedInForeignApp {
            return sourceLabel
        }
        return terminalName
    }

    /// The multiplexer layered on top of the terminal, if any.
    ///
    /// Not the terminal itself: cmux is a terminal app and is already named by
    /// `terminalName`, so repeating it here would print the same word twice on
    /// one badge. Nested multiplexers each leave their env vars behind, so the
    /// innermost layer — the one the CLI actually sits in — wins, which is the
    /// same order `HerdrController.shouldRoute` uses to decide where a jump goes.
    public var multiplexerLabel: String? {
        // Under a harness the multiplexer vars were inherited from wherever the
        // harness server was started; the conversation is not in that pane, so
        // naming it would point the user at the wrong place (#321).
        if hostHarness != nil { return nil }
        if zellijPaneId != nil || zellijSessionName != nil { return "zellij" }
        if tmuxEnv != nil || tmuxPane != nil { return "tmux" }
        if hasHerdrRoute { return "herdr" }
        return nil
    }

    /// Herdr routing needs both halves: a pane id aimed at the wrong server is
    /// worse than no routing at all, so an incomplete pair is treated as absent.
    public var hasHerdrRoute: Bool {
        guard let pane = herdrPaneId?.trimmingCharacters(in: .whitespacesAndNewlines), !pane.isEmpty,
              let socket = herdrSocketPath?.trimmingCharacters(in: .whitespacesAndNewlines),
              socket.hasPrefix("/") else {
            return false
        }
        return true
    }

    /// Short terminal/app name for display tag
    public var terminalName: String? {
        if isRemote {
            return remoteDisplayName ?? "Remote"
        }
        // AiWork (formerly DTCoder): badge names match Hooks settings.
        if source == "aiwork" { return "AiWork" }
        if source == "aiwork-cli" { return "AiWork CLI" }
        // If termBundleId is a known app, show app name (APP mode)
        if let bid = termBundleId, let name = Self.appBundleNames[bid] {
            return name
        }
        // Check bundle ID for terminal identification (more reliable than TERM_PROGRAM)
        if let bid = termBundleId {
            let lower = bid.lowercased()
            if lower.contains("cmux") { return "cmux" }
            if lower.contains("warp") { return "Warp" }
            if lower == "com.mitchellh.ghostty" { return "Ghostty" }
            if lower.contains("iterm2") { return "iTerm2" }
            if lower.contains("kitty") { return "Kitty" }
            if lower.contains("alacritty") { return "Alacritty" }
            if lower.contains("wezterm") { return "WezTerm" }
            // IDE integrated terminals
            if lower.contains("vscode") || lower.contains("vscodium") { return "VS Code" }
            if lower == "com.trae.app" { return "Trae" }
            if lower == "cn.trae.app" { return "Trae CN" }
            if lower.contains("windsurf") { return "Windsurf" }
            if lower.contains("jetbrains") {
                if lower.contains("intellij") { return "IDEA" }
                if lower.contains("pycharm") { return "PyCharm" }
                if lower.contains("webstorm") { return "WebStorm" }
                if lower.contains("goland") { return "GoLand" }
                if lower.contains("clion") { return "CLion" }
                if lower.contains("rider") { return "Rider" }
                if lower.contains("rubymine") { return "RubyMine" }
                if lower.contains("phpstorm") { return "PhpStorm" }
                if lower.contains("datagrip") { return "DataGrip" }
                return "JetBrains"
            }
            if lower.contains("zed") { return "Zed" }
            if lower.contains("xcode") || lower == "com.apple.dt.xcode" { return "Xcode" }
            if lower.contains("panic.nova") { return "Nova" }
            if lower.contains("android.studio") { return "Android Studio" }
            if lower.contains("antigravity") { return "Antigravity" }
        }
        // Superset spoofs TERM_PROGRAM to "kitty" and strips __CFBundleIdentifier, so the only
        // way to label it correctly is its own SUPERSET_* env vars. Check before the TERM_PROGRAM
        // fallback below, otherwise it would mislabel as "Kitty". (#213)
        if supersetWorkspaceId != nil || supersetPaneId != nil { return "Superset" }
        // Orca strips TERM_PROGRAM for Claude Agent Teams sessions, so its own
        // ORCA_* vars are the only label that survives every launch path (#302).
        if orcaTerminalHandle != nil || orcaWorktreeId != nil { return "Orca" }
        // Fallback to TERM_PROGRAM
        guard let app = termApp else { return nil }
        let lower = app.lowercased()
        if lower.contains("cmux") { return "cmux" }
        if lower == "ghostty" { return "Ghostty" }
        if lower.contains("iterm") { return "iTerm2" }
        if lower.contains("warp") { return "Warp" }
        if lower.contains("alacritty") { return "Alacritty" }
        if lower.contains("kitty") { return "Kitty" }
        if lower.contains("terminal") { return "Terminal" }
        return app
    }

    /// Subtitle: cwd path or model info
    public var subtitle: String? {
        if let cwd = cwd {
            // Show parent/folder instead of just folder
            let parts = cwd.split(separator: "/")
            let pathText: String
            if parts.count >= 2 {
                pathText = "\(parts[parts.count - 2])/\(parts[parts.count - 1])"
            } else {
                pathText = cwd
            }
            if let remote = remoteDisplayName {
                return "\(pathText) · \(remote)"
            }
            return pathText
        }
        if let remote = remoteDisplayName {
            return remote
        }
        return model
    }
}

public struct SessionSummary {
    public let status: AgentStatus
    public let primarySource: String
    public let activeSessionCount: Int
    public let totalSessionCount: Int

    public init(status: AgentStatus, primarySource: String, activeSessionCount: Int, totalSessionCount: Int) {
        self.status = status
        self.primarySource = primarySource
        self.activeSessionCount = activeSessionCount
        self.totalSessionCount = totalSessionCount
    }
}

public func deriveSessionSummary(from sessions: [String: SessionSnapshot]) -> SessionSummary {
    var highestStatus: AgentStatus = .idle
    var source = "claude"
    var active = 0
    var mostRecentIdleSource: (source: String, time: Date)?

    for session in sessions.values {
        if session.status != .idle {
            active += 1
        } else if mostRecentIdleSource == nil || session.lastActivity > mostRecentIdleSource!.time {
            mostRecentIdleSource = (session.source, session.lastActivity)
        }

        switch session.status {
        case .waitingApproval:
            highestStatus = .waitingApproval
            source = session.source
        case .waitingQuestion:
            if highestStatus != .waitingApproval {
                highestStatus = .waitingQuestion
                source = session.source
            }
        case .running:
            if highestStatus == .idle || highestStatus == .processing {
                highestStatus = .running
                source = session.source
            }
        case .processing:
            if highestStatus == .idle {
                highestStatus = .processing
                source = session.source
            }
        case .idle:
            break
        }
    }

    if highestStatus == .idle, let idleSource = mostRecentIdleSource?.source {
        source = idleSource
    }

    return SessionSummary(
        status: highestStatus,
        primarySource: source,
        activeSessionCount: active,
        totalSessionCount: sessions.count
    )
}

// MARK: - Side Effects

public enum SideEffect: Equatable {
    case playSound(String)
    case tryMonitorSession(sessionId: String)
    case stopMonitor(sessionId: String)
    case removeSession(sessionId: String)
    case enqueueCompletion(sessionId: String)
    case setActiveSession(sessionId: String?)
}

// MARK: - Pure Reducer

/// A hook event applied to the sessions: the lifecycle effects for the
/// caller to execute (never `.playSound` or `.enqueueCompletion`), and what
/// the event did, for `AttentionPolicy` to decide whether the user hears
/// about it.
public struct HookEventReduction {
    public var effects: [SideEffect]
    public var facts: HookEventFacts
    /// Where the reducer used to put `.enqueueCompletion` and `.playSound`,
    /// for `reduceEvent` to put the policy's intents back.
    fileprivate var slots = AttentionEffectSlots()
}

/// Indexes into a reduction's effects: where the turn ended (the completion
/// went in) and where the event finished moving its session (the sound
/// went in, ahead of the closing switch of the active session).
fileprivate struct AttentionEffectSlots {
    var completion: Int?
    var sound: Int?
}

/// Pure reducer: mutates sessions and reports what happened. Whether that
/// rings, pops a card, pushes or gets a follow-up is `AttentionPolicy`'s call.
public func reduceHookEvent(
    sessions: inout [String: SessionSnapshot],
    event: HookEvent,
    maxHistory: Int,
    replyCompletePlaceholder: String = "Reply complete"
) -> HookEventReduction {
    var facts = HookEventFacts(event: event)
    var slots = AttentionEffectSlots()
    let effects = applyHookEvent(
        sessions: &sessions,
        event: event,
        maxHistory: maxHistory,
        replyCompletePlaceholder: replyCompletePlaceholder,
        facts: &facts,
        slots: &slots
    )
    if facts.endedTurn {
        let sessionId = event.sessionId ?? "default"
        facts.subagentTurn = PushEventClassifier.isSubagentCompletion(
            agentId: event.agentId,
            raw: event.rawJSON,
            sessionId: sessionId,
            session: sessions[sessionId]
        )
    }
    return HookEventReduction(effects: effects, facts: facts, slots: slots)
}

/// The reducer followed by `AttentionPolicy`'s own reading of the event:
/// `.enqueueCompletion` and `.playSound` are the policy's intents, before the
/// user's settings and the room have their say. The app runs the two halves
/// itself — ``reduceHookEvent`` now, the policy with the context it gathers
/// once the event has settled — and this keeps an event's whole story
/// checkable in one call, in the order the reducer always returned it.
public func reduceEvent(
    sessions: inout [String: SessionSnapshot],
    event: HookEvent,
    maxHistory: Int,
    replyCompletePlaceholder: String = "Reply complete"
) -> [SideEffect] {
    let reduction = reduceHookEvent(
        sessions: &sessions,
        event: event,
        maxHistory: maxHistory,
        replyCompletePlaceholder: replyCompletePlaceholder
    )
    let sessionId = event.sessionId ?? "default"
    let intents = AttentionPolicy.intents(
        for: .hookEvent(reduction.facts),
        subject: AttentionSubject(sessions[sessionId])
    )
    // Exactly where the reducer used to put them: the sound (later in the
    // list) first, so the completion's slot still points where it should.
    var effects = reduction.effects
    if let sound = intents.sound {
        effects.insert(.playSound(sound), at: reduction.slots.sound ?? effects.count)
    }
    if intents.completion != nil {
        effects.insert(.enqueueCompletion(sessionId: sessionId), at: reduction.slots.completion ?? effects.count)
    }
    return effects
}

/// Whether `event` is Claude Code compacting a finished session in the
/// background. While a session sits idle, Claude Code compacts it ahead of
/// the prompt cache expiring (about 54 minutes after the turn ended; its
/// `idleCompaction` setting). It reports PreCompact — trigger "auto", the
/// same as a compaction mid-turn — and no turn follows, so no Stop. Read
/// as work, the PreCompact left a finished card on "thinking" for good, or
/// brought one the idle sweep had removed back as "thinking". The
/// compaction's other hooks are ``BackgroundCompactionFilter``'s, which
/// AppState asks first. A manual /compact is the user's doing and still
/// shows.
public func isIdleBackgroundCompaction(_ event: HookEvent, session: SessionSnapshot?) -> Bool {
    let source = SessionSnapshot.normalizedSupportedSource(event.rawJSON["_source"] as? String) ?? "claude"
    guard source == "claude" else { return false }
    let eventName = EventNormalizer.normalize(event.eventName)
    guard eventName == "PreCompact" || eventName == "PostCompact",
          event.agentId == nil,
          (event.rawJSON["trigger"] as? String) != "manual" else { return false }
    return session == nil || session?.status == .idle
}

private func applyHookEvent(
    sessions: inout [String: SessionSnapshot],
    event: HookEvent,
    maxHistory: Int,
    replyCompletePlaceholder: String,
    facts: inout HookEventFacts,
    slots: inout AttentionEffectSlots
) -> [SideEffect] {
    let sessionId = event.sessionId ?? "default"
    let eventName = EventNormalizer.normalize(event.eventName)
    var effects: [SideEffect] = []

    if isIdleBackgroundCompaction(event, session: sessions[sessionId]) {
        return effects
    }

    // Ensure session exists
    if sessions[sessionId] == nil {
        sessions[sessionId] = SessionSnapshot()
    }

    // Always update metadata from parent events. Subagent events are routed
    // through the parent session ID, so applying their full metadata here would
    // overwrite the parent's model/transcript/title with child-session values.
    // Still fill *missing* identity fields so a merge-first Task hook does not
    // leave the parent stuck as the default `source == "claude"`.
    if event.agentId == nil {
        extractMetadata(into: &sessions, sessionId: sessionId, event: event)
    } else {
        fillMissingParentMetadataFromSubagentEvent(into: &sessions, sessionId: sessionId, event: event)
    }
    let isRemote = sessions[sessionId]?.isRemote == true

    // Cline ships hooks via shell scripts that spawn the bridge in the background,
    // so events for the same session can arrive out of order. Once a task round
    // ends (TaskComplete/TaskCancel), drop any in-flight tool events that race in
    // afterwards — they would otherwise revive the session into .processing/.running.
    // The next TaskStart (SessionStart) or TaskResume (UserPromptSubmit) clears the flag.
    if sessions[sessionId]?.source == "cline",
       sessions[sessionId]?.taskRoundEnded == true,
       eventName != "SessionStart",
       eventName != "UserPromptSubmit" {
        return effects
    }

    // Codex may flush already queued tool hooks after an Interrupt. Keep the
    // terminal state latched until a new prompt/session starts so stale work
    // cannot revive the card as processing.
    //
    // SubagentStop still passes: interrupting the root turn does not stop
    // spawned agents, and dropping their stop would leave them in `subagents`
    // so the next root Stop sees "active subagents" and pins the card to
    // running/Agent. Removing a subagent never revives an idle parent.
    if sessions[sessionId]?.source == "codex",
       sessions[sessionId]?.interrupted == true,
       eventName != "SessionStart",
       eventName != "UserPromptSubmit",
       eventName != "SessionEnd",
       eventName != "SubagentStop",
       eventName != "Interrupt" {
        return effects
    }

    // Route subagent-specific events
    if let agentId = event.agentId {
        // Subagents and teammates share the parent's task list: their
        // TaskUpdate calls move the parent's rows too. Their own creates stay
        // off the parent card (see applySharedUpdates).
        let sharedTaskEvents = AgentTaskHookParser.events(from: event, normalizedEventName: eventName)
        if !sharedTaskEvents.isEmpty {
            sessions[sessionId]?.agentTasks.applySharedUpdates(sharedTaskEvents, now: Date())
        }
        let handled = handleSubagentEvent(
            sessions: &sessions,
            sessionId: sessionId,
            agentId: agentId,
            eventName: eventName,
            event: event,
            maxHistory: maxHistory,
            effects: &effects
        )
        recordSubagentModel(sessions: &sessions, sessionId: sessionId, agentId: agentId, event: event)
        recordFoldedSubsession(sessions: &sessions, sessionId: sessionId, agentId: agentId, event: event)
        if handled { return effects }
    }

    // Remote Codex hooks can enrich ordinary lifecycle events with the latest
    // public assistant text because their transcript path is not readable on
    // this Mac. Apply it only after stale/interrupted and subagent events have
    // been filtered, and keep it separate from persisted chat history.
    if sessions[sessionId]?.source == "codex",
       eventName != "UserPromptSubmit",
       eventName != "SessionStart",
       let output = event.rawJSON["last_assistant_message"] as? String {
        let trimmed = output.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty {
            sessions[sessionId]?.liveCodexOutput = trimmed
        }
    }

    // Preserve actionable states: don't let activity updates overwrite waiting states
    let isWaiting = sessions[sessionId]?.status == .waitingApproval
        || sessions[sessionId]?.status == .waitingQuestion

    // Agent checklist progress. Subagent tool events were consumed by
    // handleSubagentEvent above (after their shared-list updates), so a
    // child's own list never lands here.
    let agentTasksBeforeEvent = sessions[sessionId]?.agentTasks
    let agentTaskEvents = AgentTaskHookParser.events(from: event, normalizedEventName: eventName)
    if !agentTaskEvents.isEmpty {
        sessions[sessionId]?.agentTasks.apply(agentTaskEvents, now: Date())
    }

    // Update this session's state
    switch eventName {
    case "UserPromptSubmit":
        sessions[sessionId]?.interrupted = false
        sessions[sessionId]?.lastTurnFailed = false
        sessions[sessionId]?.taskRoundEnded = false
        sessions[sessionId]?.clearRecapIfSuperseded(byPromptAt: Date())
        if sessions[sessionId]?.source == "codex" {
            sessions[sessionId]?.liveCodexOutput = nil
        }
        sessions[sessionId]?.status = .processing
        sessions[sessionId]?.currentTool = nil
        sessions[sessionId]?.toolDescription = nil
        // Separate-mode Cursor Task Stop self-tombstones; a new prompt means relaunch.
        if let source = sessions[sessionId]?.source,
           source == "cursor" || source == "cursor-cli" {
            sessions[sessionId]?.clearClosedSubagentId(sessionId)
        }
        // Probe a wider set of field names + nested containers. Qwen Code (#103)
        // and most Claude forks put the prompt at "prompt" top-level, but some
        // forks nest it inside `input` / `data` / `payload` / `params`, Hermes's
        // pre_llm_call sends `extra.user_message`, and Cursor's
        // `beforeSubmitPrompt` uses a different shape. Empty strings are skipped
        // so we don't insert blank chat rows when a hook fires with a placeholder.
        let prompt = firstStringFromEvent(
            event,
            keys: ["prompt", "user_prompt", "userPrompt", "user_message", "message", "input", "content", "text"],
            includeNested: true
        )
        if let prompt {
            if sessions[sessionId]?.source == "hermes" {
                sessions[sessionId]?.hermesHooksReportPrompts = true
            }
            sessions[sessionId]?.lastUserPrompt = prompt
            if sessions[sessionId]?.recentMessages.last?.isUser == true {
                sessions[sessionId]?.recentMessages.removeLast()
            }
            sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: true, text: prompt))
        }
    case "PreToolUse":
        if !isWaiting {
            sessions[sessionId]?.status = .running
            sessions[sessionId]?.currentTool = event.activityLabel
            sessions[sessionId]?.currentToolUseId = event.toolUseId
            sessions[sessionId]?.toolDescription = event.toolDescription
        }
    case "PostToolUse", "PostToolUseFailure":
        let success = eventName == "PostToolUse"
        if sessions[sessionId]?.finishesAnotherToolUse(event) == true {
            // An earlier tool's step, overtaken by the next tool's start:
            // it is recorded from its own payload, and the running tool
            // stays up.
            if let tool = event.activityLabel {
                sessions[sessionId]?.recordTool(tool, description: event.toolDescription, success: success, agentType: nil, maxHistory: maxHistory)
            }
            break
        }
        if let tool = sessions[sessionId]?.currentTool {
            let desc = sessions[sessionId]?.toolDescription
            sessions[sessionId]?.recordTool(tool, description: desc, success: success, agentType: nil, maxHistory: maxHistory)
        }
        if !isWaiting {
            sessions[sessionId]?.status = .processing
            sessions[sessionId]?.currentTool = nil
            sessions[sessionId]?.toolDescription = nil
        }
    case "PermissionDenied":
        if !isWaiting {
            sessions[sessionId]?.status = .processing
            sessions[sessionId]?.currentTool = nil
            sessions[sessionId]?.toolDescription = nil
        }
    case "SubagentStart":
        if !isWaiting {
            sessions[sessionId]?.status = .running
            sessions[sessionId]?.currentTool = "Agent"
            sessions[sessionId]?.toolDescription = event.rawJSON["agent_type"] as? String
        }
    case "SubagentStop":
        if !isWaiting {
            sessions[sessionId]?.status = .processing
            sessions[sessionId]?.currentTool = nil
            sessions[sessionId]?.toolDescription = nil
        }
    case "AfterAgentResponse":
        // Cursor-specific: AI reply arrives here (in "text" field), not in Stop
        let responseText = firstStringFromEvent(
            event,
            keys: ["text", "message"],
            includeNested: true
        )
        if let text = responseText, !text.isEmpty {
            sessions[sessionId]?.lastAssistantMessage = text
            sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: false, text: text))
        }
        let hasActiveSubagents = sessions[sessionId]?.subagents.values.contains {
            $0.status != .idle
        } == true
        if let source = sessions[sessionId]?.source,
           SessionSnapshot.ideCompletionSources.contains(source) {
            // Parent chat finished a turn while folded Tasks are still working —
            // keep the card active and do not pop a premature completion.
            if hasActiveSubagents {
                if !isWaiting {
                    sessions[sessionId]?.status = .running
                    if sessions[sessionId]?.currentTool == nil {
                        sessions[sessionId]?.currentTool = "Agent"
                    }
                }
            } else {
                sessions[sessionId]?.status = .idle
                sessions[sessionId]?.currentTool = nil
                sessions[sessionId]?.toolDescription = nil
                facts.endedTurn = true
                slots.completion = effects.count
            }
        } else {
            sessions[sessionId]?.status = .processing
        }
    case "AgentTurnSettled":
        // Hermes's post_llm_call: the turn's final reply, sent just before
        // on_session_end (Stop) ends the turn. Drop the tool chrome and record
        // the reply; the completion belongs to the Stop that follows.
        sessions[sessionId]?.currentTool = nil
        sessions[sessionId]?.toolDescription = nil
        // It repeats the turn's prompt. Without an approved pre_llm_call hook
        // this is the first the card hears of it, so it goes in ahead of the reply.
        if let prompt = firstStringFromEvent(event, keys: ["user_message"], includeNested: true),
           prompt != sessions[sessionId]?.lastUserPrompt {
            sessions[sessionId]?.lastUserPrompt = prompt
            if sessions[sessionId]?.recentMessages.last?.isUser == true {
                sessions[sessionId]?.recentMessages.removeLast()
            }
            sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: true, text: prompt))
        }
        if let msg = firstStringFromEvent(
            event,
            keys: ["assistant_response", "last_assistant_message", "text", "message"],
            includeNested: true
        ), !msg.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty {
            sessions[sessionId]?.hermesHooksReportReplies = true
            sessions[sessionId]?.lastAssistantMessage = msg
            // A store read can land the same reply a moment before this hook.
            let alreadyShown = sessions[sessionId]?.recentMessages.last.map { !$0.isUser && $0.text == msg } ?? false
            if !alreadyShown {
                sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: false, text: msg))
            }
        }
        if !isWaiting {
            sessions[sessionId]?.status = .processing
        }
    case "TaskRoundComplete":
        sessions[sessionId]?.interrupted = (event.eventName == "TaskCancel")
        sessions[sessionId]?.status = .processing
        sessions[sessionId]?.currentTool = nil
        sessions[sessionId]?.toolDescription = nil
        let assistantMsg = firstStringFromEvent(
            event,
            keys: ["last_assistant_message", "text", "message", "summary"],
            includeNested: true
        )
        if let msg = assistantMsg {
            sessions[sessionId]?.lastAssistantMessage = msg
            sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: false, text: msg))
        } else if sessions[sessionId]?.lastAssistantMessage == nil,
                  sessions[sessionId]?.recentMessages.last?.isUser == true {
            sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: false, text: replyCompletePlaceholder))
        }
        // Cline tasks are single-round — treat completion/cancellation as session end,
        // and latch a flag so out-of-order in-flight tool events don't revive it.
        if sessions[sessionId]?.source == "cline" {
            sessions[sessionId]?.status = .idle
            sessions[sessionId]?.taskRoundEnded = true
        }
        facts.endedTurn = true
        slots.completion = effects.count
    case "Stop":
        // Hermes fires on_session_end at the end of every turn. A delegate_task
        // child or a scheduled job runs just one, so its turn ending is its
        // card ending.
        if HermesHookPayload.endsOneShotRun(event) {
            effects.append(.removeSession(sessionId: sessionId))
            return effects
        }
        // Detect ESC/Ctrl+C interruption
        let stopReason = event.rawJSON["stop_reason"] as? String ?? ""
        let wasInterrupted = (stopReason == "user" || stopReason == "interrupted")
            || HermesHookPayload.endsInterruptedTurn(event)
        let hasActiveSubagents = sessions[sessionId]?.subagents.values.contains {
            $0.status != .idle
        } == true
        // Separate-mode Cursor Tasks have no agent_id, so merge later must see
        // this id as closed — otherwise a still-live IDE `_ppid` resuscitates them.
        // Only self-tombstone foldable Task cards (transcript parent ≠ session id),
        // never the parent chat — that would suppress late Permission UI and wipe
        // the IDE `_ppid` monitor after a normal turn Stop.
        if !hasActiveSubagents,
           let source = sessions[sessionId]?.source,
           source == "cursor" || source == "cursor-cli",
           CursorSessionFolding.foldTarget(
               childSessionId: sessionId,
               transcriptPath: sessions[sessionId]?.transcriptPath
           ) != nil {
            sessions[sessionId]?.recordClosedSubagentId(sessionId)
            // Drop process identity so a still-open IDE `_ppid` does not look like
            // a live Task after Stop when the card is later considered for merge.
            sessions[sessionId]?.cliPid = nil
            sessions[sessionId]?.cliStartTime = nil
        }

        let assistantMsg = firstStringFromEvent(
            event,
            keys: ["last_assistant_message", "text", "message", "summary"],
            includeNested: true
        )
        if let msg = assistantMsg {
            sessions[sessionId]?.lastAssistantMessage = msg
            // Stop's last_assistant_message (Claude Code, Codex, mcode, …) is
            // often the reply the transcript tailer already appended, and with
            // maxCount 3 a duplicate crowds a real row off the card. Skip it
            // only when that reply is the newest row: after a new prompt, the
            // same text is a new answer and still lands.
            let normalizedIncoming = JSONLTailer.normalizedCursorChatText(from: msg) ?? msg
            let alreadyShown = sessions[sessionId]?.recentMessages.last.map {
                !$0.isUser && (JSONLTailer.normalizedCursorChatText(from: $0.text) ?? $0.text) == normalizedIncoming
            } ?? false
            if !alreadyShown {
                sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: false, text: msg))
            }
        } else if sessions[sessionId]?.lastAssistantMessage == nil,
                  sessions[sessionId]?.recentMessages.last?.isUser == true {
            // No reply content from hook (e.g. CodeBuddy) -- add placeholder
            sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: false, text: replyCompletePlaceholder))
        }
        // Try to capture user prompt from Stop event if not already set
        if sessions[sessionId]?.lastUserPrompt == nil {
            if let prompt = event.rawJSON["last_user_message"] as? String {
                sessions[sessionId]?.lastUserPrompt = prompt
                let insertAt = max(0, (sessions[sessionId]?.recentMessages.count ?? 1) - 1)
                sessions[sessionId]?.insertRecentMessage(ChatMessage(isUser: true, text: prompt), at: insertAt)
            }
        }

        // Parent chat Stop while folded Tasks are still working — keep the card
        // active and do not pop a premature completion (same as AfterAgentResponse).
        if hasActiveSubagents {
            if !isWaiting {
                sessions[sessionId]?.status = .running
                if sessions[sessionId]?.currentTool == nil {
                    sessions[sessionId]?.currentTool = "Agent"
                }
            }
            // Do not latch `interrupted` onto a still-active parent+Task card.
        } else {
            sessions[sessionId]?.interrupted = wasInterrupted
            sessions[sessionId]?.status = .idle
            sessions[sessionId]?.currentTool = nil
            sessions[sessionId]?.toolDescription = nil
            facts.endedTurn = true
            slots.completion = effects.count
        }
    case "SessionStart":
        // A link an AppState pass made (the split on switching to Show
        // separately, discovery) is on the card, not in the child's hooks:
        // the rebuild keeps it unless the hook names a parent itself.
        let linkedParentId = sessions[sessionId]?.parentSessionId
        effects.append(.stopMonitor(sessionId: sessionId))
        sessions[sessionId] = SessionSnapshot(startTime: Date())
        // Re-apply metadata from this event (common extraction above wrote to the old session)
        if let cwd = event.rawJSON["cwd"] as? String, !cwd.isEmpty { sessions[sessionId]?.cwd = cwd }
        if let model = hookReportedModel(event) {
            sessions[sessionId]?.model = model
            sessions[sessionId]?.modelReportedAt = Date()
        }
        applyHookProcessId(into: &sessions, sessionId: sessionId, event: event)
        if let source = SessionSnapshot.normalizedSupportedSource(event.rawJSON["_source"] as? String) {
            sessions[sessionId]?.source = source
        }
        if let app = event.rawJSON["_term_app"] as? String, !app.isEmpty { sessions[sessionId]?.termApp = app }
        if let bundle = event.rawJSON["_term_bundle"] as? String, !bundle.isEmpty { sessions[sessionId]?.termBundleId = bundle }
        if let ses = event.rawJSON["_iterm_session"] as? String, !ses.isEmpty { sessions[sessionId]?.itermSessionId = ses }
        if let tty = event.rawJSON["_tty"] as? String, !tty.isEmpty { sessions[sessionId]?.ttyPath = tty }
        if let kitty = event.rawJSON["_kitty_window"] as? String, !kitty.isEmpty { sessions[sessionId]?.kittyWindowId = kitty }
        if let pane = event.rawJSON["_tmux_pane"] as? String, !pane.isEmpty { sessions[sessionId]?.tmuxPane = pane }
        if let tmuxTty = event.rawJSON["_tmux_client_tty"] as? String, !tmuxTty.isEmpty { sessions[sessionId]?.tmuxClientTty = tmuxTty }
        if let tmux = event.rawJSON["_tmux"] as? String, !tmux.isEmpty { sessions[sessionId]?.tmuxEnv = tmux }
        if let mode = event.rawJSON["permission_mode"] as? String { sessions[sessionId]?.permissionMode = mode }
        if let roots = event.rawJSON["workspace_roots"] as? [String], let first = roots.first, !first.isEmpty {
            sessions[sessionId]?.cwd = first
        }
        // cmux surface / workspace (restore directly from payload on SessionStart to avoid extractMetadata ordering dependency)
        if let surface = event.rawJSON["_cmux_surface_id"] as? String, !surface.isEmpty {
            sessions[sessionId]?.cmuxSurfaceId = surface
        }
        if let workspace = event.rawJSON["_cmux_workspace_id"] as? String, !workspace.isEmpty {
            sessions[sessionId]?.cmuxWorkspaceId = workspace
        }
        if let zellijPane = event.rawJSON["_zellij_pane_id"] as? String, !zellijPane.isEmpty {
            sessions[sessionId]?.zellijPaneId = zellijPane
        }
        if let zellijSession = event.rawJSON["_zellij_session_name"] as? String, !zellijSession.isEmpty {
            sessions[sessionId]?.zellijSessionName = zellijSession
        }
        if let weztermPane = event.rawJSON["_wezterm_pane"] as? String, !weztermPane.isEmpty {
            sessions[sessionId]?.weztermPaneId = weztermPane
        }
        applyHerdrRoute(into: &sessions, sessionId: sessionId, event: event)
        if let supersetWs = event.rawJSON["_superset_workspace_id"] as? String, !supersetWs.isEmpty {
            sessions[sessionId]?.supersetWorkspaceId = supersetWs
        }
        if let supersetPane = event.rawJSON["_superset_pane_id"] as? String, !supersetPane.isEmpty {
            sessions[sessionId]?.supersetPaneId = supersetPane
        }
        if let hostId = claudeDesktopSessionId(in: event) {
            sessions[sessionId]?.claudeDesktopSessionId = hostId
        }
        if let env = event.rawJSON["_env"] as? [String: String] {
            applyEnvMetadata(into: &sessions, sessionId: sessionId, env: env)
        }
        if let remoteHostId = event.rawJSON["_remote_host_id"] as? String, !remoteHostId.isEmpty {
            sessions[sessionId]?.remoteHostId = remoteHostId
        }
        if let remoteHostName = event.rawJSON["_remote_host_name"] as? String, !remoteHostName.isEmpty {
            sessions[sessionId]?.remoteHostName = remoteHostName
        }
        if let providerSessionId = event.rawJSON["session_id"] as? String,
           !providerSessionId.isEmpty,
           sessions[sessionId]?.isRemote == true
                || (sessions[sessionId]?.source == "codex"
                    && sessions[sessionId]?.termBundleId == "com.openai.codex") {
            let isCodexDesktop = sessions[sessionId]?.source == "codex"
                && sessions[sessionId]?.termBundleId == "com.openai.codex"
            sessions[sessionId]?.providerSessionId = isCodexDesktop
                ? normalizedCodexDesktopProviderSessionId(providerSessionId)
                : providerSessionId
        }
        if let sessionTitle = event.rawJSON["session_title"] as? String,
           !sessionTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            sessions[sessionId]?.sessionTitle = sessionTitle
        }
        sessions[sessionId]?.parentSessionId = SubsessionRouter.parentCardId(in: event.rawJSON) ?? linkedParentId
        if !isRemote {
            effects.append(.tryMonitorSession(sessionId: sessionId))
        }
    case "SessionEnd":
        // Side effect: AppState drops the session's pending requests, undecided, before removal
        effects.append(.removeSession(sessionId: sessionId))
        return effects
    case "Notification":
        let notificationText = firstStringFromEvent(
            event,
            keys: ["message", "text", "summary", "status", "detail"],
            includeNested: true
        )
        if let msg = notificationText, !msg.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty {
            sessions[sessionId]?.toolDescription = msg
        }
        if QuestionPayload.from(event: event) != nil {
            sessions[sessionId]?.status = .waitingQuestion
        } else {
            // Notifications that describe what the agent is waiting for. A
            // Notification cannot block (it is observe-only), so this is a
            // display-only wait: the decision is made in the terminal, and the
            // next PostToolUse/Stop clears it via the existing wasWaiting drain.
            // Without this the card sat on "thinking" while the CLI was in fact
            // blocked on the user (#290).
            switch notificationKind(from: event) {
            case "permission_prompt":
                sessions[sessionId]?.status = .waitingApproval
            case "idle_prompt":
                // "Waiting for your input after 60s idle" — the turn is over.
                sessions[sessionId]?.status = .idle
            default:
                break
            }
        }
    case "PreCompact":
        sessions[sessionId]?.status = .processing
        if sessions[sessionId]?.source == "codex" {
            sessions[sessionId]?.currentTool = "Compacting"
        }
        sessions[sessionId]?.toolDescription = "Compacting context\u{2026}"
    case "PostCompact":
        if !isWaiting {
            sessions[sessionId]?.status = .processing
            sessions[sessionId]?.currentTool = nil
            sessions[sessionId]?.toolDescription = nil
        }
    case "Interrupt":
        sessions[sessionId]?.interrupted = true
        sessions[sessionId]?.status = .idle
        sessions[sessionId]?.currentTool = nil
        sessions[sessionId]?.toolDescription = nil
        facts.endedTurn = true
        slots.completion = effects.count
    default:
        break
    }

    // A remote Hermes hook reads the session's store on its own host (there
    // is no file to read here) and attaches what it found. Applied after the
    // event itself, so a prompt this very hook reported wins over the store.
    if let store = HermesSessionStore.Snapshot(payload: event.rawJSON["_hermes_store"]) {
        sessions[sessionId]?.applyHermesStore(store)
    }
    // After the switch: SessionStart rebuilt the snapshot.
    if HermesHookPayload.platform(of: event) != nil {
        sessions[sessionId]?.hermesChatElsewhere = HermesHookPayload.isQuiet(event)
    }

    // SessionStart rebuilt the snapshot, but a resumed or compacted
    // conversation is still working through the same checklist. /clear
    // starts the conversation over — even when it keeps the session id — so
    // the old checklist goes with it.
    if eventName == "SessionStart", let agentTasksBeforeEvent,
       (event.rawJSON["source"] as? String)?.lowercased() != "clear" {
        sessions[sessionId]?.agentTasks = agentTasksBeforeEvent
    }

    sessions[sessionId]?.lastActivity = Date()

    // Ensure process monitor is set up (covers sessions created implicitly)
    if sessions[sessionId]?.cwd != nil, !isRemote {
        effects.append(.tryMonitorSession(sessionId: sessionId))
    }

    // The event reached this session's own state. Whether it rings, pops a
    // completion card or pushes — a declared child's never do (#378), nor a
    // Hermes gateway chat's (#364) — is AttentionPolicy's call.
    facts.appliedToSession = true
    slots.sound = effects.count

    // Switch display to the session that just had activity
    if eventName == "Stop" {
        // Stop event: keep activeSessionId on completed session (set when its completion card shows)
    } else if sessions[sessionId]?.status != .idle {
        effects.append(.setActiveSession(sessionId: sessionId))
    }
    // Note: the "else if activeSessionId == sessionId → mostActive" case
    // is handled by AppState since it needs to check current activeSessionId

    return effects
}

// MARK: - Private Helpers

private func applyEnvMetadata(into sessions: inout [String: SessionSnapshot], sessionId: String, env: [String: String]) {
    if sessions[sessionId]?.termApp == nil,
       let app = env["TERM_PROGRAM"], !app.isEmpty {
        sessions[sessionId]?.termApp = app
    }
    if sessions[sessionId]?.termBundleId == nil,
       let bundle = env["__CFBundleIdentifier"], !bundle.isEmpty {
        sessions[sessionId]?.termBundleId = bundle
    }
    if sessions[sessionId]?.itermSessionId == nil,
       let ses = env["ITERM_SESSION_ID"], !ses.isEmpty {
        if let colonIdx = ses.firstIndex(of: ":") {
            sessions[sessionId]?.itermSessionId = String(ses[ses.index(after: colonIdx)...])
        } else {
            sessions[sessionId]?.itermSessionId = ses
        }
    }
    if sessions[sessionId]?.kittyWindowId == nil,
       let kitty = env["KITTY_WINDOW_ID"], !kitty.isEmpty {
        sessions[sessionId]?.kittyWindowId = kitty
    }
    if sessions[sessionId]?.tmuxEnv == nil,
       let tmux = env["TMUX"], !tmux.isEmpty {
        sessions[sessionId]?.tmuxEnv = tmux
    }
    if sessions[sessionId]?.tmuxPane == nil,
       let pane = env["TMUX_PANE"], !pane.isEmpty {
        sessions[sessionId]?.tmuxPane = pane
    }
    if sessions[sessionId]?.cmuxSurfaceId == nil,
       let surface = env["CMUX_SURFACE_ID"], !surface.isEmpty {
        sessions[sessionId]?.cmuxSurfaceId = surface
    }
    if sessions[sessionId]?.cmuxWorkspaceId == nil,
       let workspace = env["CMUX_WORKSPACE_ID"], !workspace.isEmpty {
        sessions[sessionId]?.cmuxWorkspaceId = workspace
    }
    if sessions[sessionId]?.zellijPaneId == nil,
       let pane = env["ZELLIJ_PANE_ID"], !pane.isEmpty {
        sessions[sessionId]?.zellijPaneId = pane
    }
    if sessions[sessionId]?.zellijSessionName == nil,
       let name = env["ZELLIJ_SESSION_NAME"], !name.isEmpty {
        sessions[sessionId]?.zellijSessionName = name
    }
    if sessions[sessionId]?.weztermPaneId == nil,
       let pane = env["WEZTERM_PANE"], !pane.isEmpty {
        sessions[sessionId]?.weztermPaneId = pane
    }
    if sessions[sessionId]?.supersetWorkspaceId == nil,
       let workspace = env["SUPERSET_WORKSPACE_ID"], !workspace.isEmpty {
        sessions[sessionId]?.supersetWorkspaceId = workspace
    }
    if sessions[sessionId]?.supersetPaneId == nil,
       let pane = env["SUPERSET_PANE_ID"] ?? env["SUPERSET_TERMINAL_ID"], !pane.isEmpty {
        sessions[sessionId]?.supersetPaneId = pane
    }
    if sessions[sessionId]?.orcaTerminalHandle == nil,
       let handle = env["ORCA_TERMINAL_HANDLE"], !handle.isEmpty {
        sessions[sessionId]?.orcaTerminalHandle = handle
    }
    if sessions[sessionId]?.orcaWorktreeId == nil,
       let worktree = env["ORCA_WORKTREE_ID"], !worktree.isEmpty {
        sessions[sessionId]?.orcaWorktreeId = worktree
    }
    if sessions[sessionId]?.claudeDesktopSessionId == nil,
       let host = env[ClaudeDesktopCodeSession.hostSessionEnvKey],
       ClaudeDesktopCodeSession.isValidHostSessionId(host) {
        sessions[sessionId]?.claudeDesktopSessionId = host
    }
}

/// Fill identity fields on a parent card from a merged Task/subagent hook.
/// Unlike `extractMetadata`, never overwrites values already set on the parent
/// (child payloads can carry Task-specific cwd/model/title).
public func fillMissingParentMetadataFromSubagentEvent(
    into sessions: inout [String: SessionSnapshot],
    sessionId: String,
    event: HookEvent
) {
    // The host is the card's as much as the child's: a remote host's hook
    // only ever describes a session on that host. Left out, a card that a
    // remote subagent's hook created looked local to every check that keeps
    // a remote session's pids, paths and terminal handles off this Mac.
    if sessions[sessionId]?.remoteHostId == nil,
       let remoteHostId = SubsessionRouter.remoteHostId(in: event.rawJSON) {
        sessions[sessionId]?.remoteHostId = remoteHostId
    }
    if sessions[sessionId]?.remoteHostName == nil,
       let remoteHostName = event.rawJSON["_remote_host_name"] as? String, !remoteHostName.isEmpty {
        sessions[sessionId]?.remoteHostName = remoteHostName
    }
    // Default SessionSnapshot.source is "claude". Upgrade when the hook carries a
    // real source so merge-first Cursor Tasks are not branded as Claude forever.
    if sessions[sessionId]?.source == "claude",
       let source = SessionSnapshot.normalizedSupportedSource(event.rawJSON["_source"] as? String)
        ?? SessionSnapshot.normalizedSupportedSource(event.rawJSON["source"] as? String),
       source != "claude" {
        sessions[sessionId]?.source = source
    }
    // Cursor Task hooks often omit `--source` and keep the default "claude".
    // Rebrand when transcript_path is clearly under Cursor agent-transcripts.
    if sessions[sessionId]?.source == "claude",
       let path = event.rawJSON["transcript_path"] as? String,
       CursorSessionFolding.isCursorAgentTranscriptPath(path) {
        sessions[sessionId]?.source = "cursor"
    }

    let cwdMissing = sessions[sessionId]?.cwd == nil
        || SessionSnapshot.isUnhelpfulHookCwd(sessions[sessionId]?.cwd ?? "")
    if cwdMissing {
        if let cwd = event.rawJSON["cwd"] as? String, !cwd.isEmpty,
           !SessionSnapshot.isUnhelpfulHookCwd(cwd) {
            sessions[sessionId]?.cwd = cwd
        } else if let roots = event.rawJSON["workspace_roots"] as? [String],
                  let first = roots.first, !first.isEmpty {
            sessions[sessionId]?.cwd = first
        } else if let tp = event.rawJSON["transcript_path"] as? String,
                  tp.contains("/.cursor/projects/") {
            let parts = tp.split(separator: "/")
            if let idx = parts.firstIndex(of: "projects"), idx + 1 < parts.count {
                let projectName = String(parts[idx + 1])
                sessions[sessionId]?.cwd = "/\(parts[...idx].joined(separator: "/"))/\(projectName)"
            }
        }
    }

    // Claude and Cursor child hooks carry the parent's transcript; a Codex
    // child's is its own rollout. Tailing that as the parent's would label
    // the parent with the child's model and effort.
    if sessions[sessionId]?.transcriptPath == nil,
       !isCodexSubagentEvent(event, session: sessions[sessionId]),
       let transcriptPath = event.rawJSON["transcript_path"] as? String, !transcriptPath.isEmpty {
        sessions[sessionId]?.transcriptPath = transcriptPath
    }

    applyHookProcessId(into: &sessions, sessionId: sessionId, event: event, fillingOnly: true)

    applyHerdrRoute(into: &sessions, sessionId: sessionId, event: event, fillingOnly: true)
    // A subagent runs inside the parent's CLI, so it carries the same id.
    if sessions[sessionId]?.claudeDesktopSessionId == nil,
       let hostId = claudeDesktopSessionId(in: event) {
        sessions[sessionId]?.claudeDesktopSessionId = hostId
    }
    // A child on a card of its own whose hooks also carry an `agent_id`
    // (Codex has sent a thread's own id as one) is still linked to its
    // parent. A hook folded into its parent's card carries no link.
    if sessions[sessionId]?.parentSessionId == nil,
       let parentSessionId = SubsessionRouter.parentCardId(in: event.rawJSON) {
        sessions[sessionId]?.parentSessionId = parentSessionId
    }
}

/// Records the Herdr pane the hook's agent runs in (`_herdr_*`, from the
/// pane's env). `fillingOnly` keeps what the card already has — a subagent's
/// hook only fills gaps on its parent's card.
///
/// A remote hook's are never recorded: its pane belongs to the Herdr on its
/// own host, and the binary path it names would be run on this Mac
/// (HerdrController).
private func applyHerdrRoute(
    into sessions: inout [String: SessionSnapshot],
    sessionId: String,
    event: HookEvent,
    fillingOnly: Bool = false
) {
    guard SubsessionRouter.remoteHostId(in: event.rawJSON) == nil else { return }
    if let pane = event.rawJSON["_herdr_pane_id"] as? String, !pane.isEmpty,
       !fillingOnly || sessions[sessionId]?.herdrPaneId == nil {
        sessions[sessionId]?.herdrPaneId = pane
    }
    if let socket = event.rawJSON["_herdr_socket_path"] as? String, !socket.isEmpty,
       !fillingOnly || sessions[sessionId]?.herdrSocketPath == nil {
        sessions[sessionId]?.herdrSocketPath = socket
    }
    if let binary = event.rawJSON["_herdr_bin_path"] as? String, !binary.isEmpty,
       !fillingOnly || sessions[sessionId]?.herdrBinaryPath == nil {
        sessions[sessionId]?.herdrBinaryPath = binary
    }
}

/// Records the process the hook's agent runs as (`_ppid`). `fillingOnly`
/// keeps one the card already has — a subagent's hook only fills gaps.
///
/// On this Mac that is the CLI the island watches (`cliPid`). A remote
/// host's is kept apart (`remotePid`), for telling that host's sessions
/// apart only: as `cliPid` it would have the island watch, probe and, on
/// orphan cleanup, SIGTERM whatever process has that number here.
private func applyHookProcessId(
    into sessions: inout [String: SessionSnapshot],
    sessionId: String,
    event: HookEvent,
    fillingOnly: Bool = false
) {
    guard let pid = hookProcessId(event) else { return }
    if SubsessionRouter.remoteHostId(in: event.rawJSON) != nil {
        if !fillingOnly || sessions[sessionId]?.remotePid == nil {
            sessions[sessionId]?.remotePid = pid
        }
    } else if fillingOnly {
        if sessions[sessionId]?.cliPid == nil {
            sessions[sessionId]?.cliPid = pid
        }
    } else if sessions[sessionId]?.cliPid != pid {
        sessions[sessionId]?.cliPid = pid
        sessions[sessionId]?.cliStartTime = nil
    }
}

/// The CLI process the bridge found for the hook (`_ppid`). A number past
/// pid_t's range comes only from a malformed payload; converting it would
/// trap.
private func hookProcessId(_ event: HookEvent) -> pid_t? {
    guard let ppid = event.rawJSON["_ppid"] as? Int, ppid > 0 else { return nil }
    return pid_t(exactly: ppid)
}

/// The Claude Desktop Code-tab id the bridge forwarded from
/// CLAUDE_CODE_HOST_SESSION_ID. Only a well-formed id is kept: it ends up in
/// a URL on click.
private func claudeDesktopSessionId(in event: HookEvent) -> String? {
    guard let hostId = event.rawJSON["_claude_desktop_session"] as? String,
          ClaudeDesktopCodeSession.isValidHostSessionId(hostId) else { return nil }
    return hostId
}

private func shouldReopenSubagentOnPrompt(event: HookEvent, session: SessionSnapshot?) -> Bool {
    // A child session folded into its parent's card (a Cursor Task, a Codex
    // thread, a pi-subagents child) starts every turn with a prompt, and none
    // sends a SubagentStart: one sent after its last Stop is a new turn of
    // the same child.
    if SubsessionRouter.foldedKind(of: event) != nil {
        return true
    }
    let source = SessionSnapshot.normalizedSupportedSource(event.rawJSON["_source"] as? String)
        ?? SessionSnapshot.normalizedSupportedSource(event.rawJSON["source"] as? String)
        ?? session?.source
    return source == "cursor" || source == "cursor-cli"
}

/// Whether a subagent-routed event comes from Codex (native child threads).
private func isCodexSubagentEvent(_ event: HookEvent, session: SessionSnapshot?) -> Bool {
    let source = SessionSnapshot.normalizedSupportedSource(event.rawJSON["_source"] as? String)
        ?? session?.source
    return source == "codex"
}

/// Whether folded-child prompt/response text should appear on the parent card.
private func shouldSurfaceCursorSubagentChat(event: HookEvent, session: SessionSnapshot?) -> Bool {
    if SubsessionRouter.foldedKind(of: event) == .cursorTask {
        return true
    }
    return CursorSubsessionRouter.isCursorFamilySource(
        (event.rawJSON["_source"] as? String)
            ?? (event.rawJSON["source"] as? String)
            ?? session?.source
    )
}

public func extractMetadata(into sessions: inout [String: SessionSnapshot], sessionId: String, event: HookEvent) {
    let eventCwd = event.rawJSON["cwd"] as? String
    if let cwd = eventCwd, !cwd.isEmpty,
       !SessionSnapshot.isUnhelpfulHookCwd(cwd) {
        sessions[sessionId]?.cwd = cwd
    }
    if sessions[sessionId]?.cwd == nil
        || SessionSnapshot.isUnhelpfulHookCwd(sessions[sessionId]?.cwd ?? ""),
       let roots = event.rawJSON["workspace_roots"] as? [String],
       let first = roots.first, !first.isEmpty {
        sessions[sessionId]?.cwd = first
    } else if sessions[sessionId]?.cwd == nil
        || SessionSnapshot.isUnhelpfulHookCwd(sessions[sessionId]?.cwd ?? ""),
              let tp = event.rawJSON["transcript_path"] as? String,
              tp.contains("/.cursor/projects/") {
        // Cursor: extract project dir from transcript_path
        // e.g. ~/.cursor/projects/<project>/agent-transcripts/... → ~/.cursor/projects/<project>
        // Must stay Cursor-scoped: Claude transcripts also contain a "projects"
        // component (~/.claude/projects/<encoded>/…) that is not a workspace.
        let parts = tp.split(separator: "/")
        if let idx = parts.firstIndex(of: "projects"), idx + 1 < parts.count {
            let projectName = String(parts[idx + 1])
            sessions[sessionId]?.cwd = "/\(parts[...idx].joined(separator: "/"))/\(projectName)"
        }
    } else if sessions[sessionId]?.cwd == nil, let cwd = eventCwd, !cwd.isEmpty {
        // Last resort: an unhelpful cwd ($HOME, ~/.claude) still beats nil —
        // transcript-based model lookup keys off it, and the display layer
        // already renders these paths as "Session".
        sessions[sessionId]?.cwd = cwd
    }
    // Git branch resolution is NOT done here: this reducer runs on the main
    // actor and .git probing can block on network mounts. AppState refreshes
    // it asynchronously after reduce (maybeRefreshGitBranch).
    if let model = hookReportedModel(event) {
        sessions[sessionId]?.model = model
        sessions[sessionId]?.modelReportedAt = Date()
    }
    if let mode = event.rawJSON["permission_mode"] as? String {
        sessions[sessionId]?.permissionMode = mode
    }
    // Hooks frequently include the absolute transcript path — capture it so the tailer
    // can attach to live appends without needing a filesystem scan to rediscover it.
    if let transcriptPath = event.rawJSON["transcript_path"] as? String, !transcriptPath.isEmpty {
        sessions[sessionId]?.transcriptPath = transcriptPath
    }
    // Terminal info (injected by hook script)
    if let app = event.rawJSON["_term_app"] as? String, !app.isEmpty, app != "unknown" {
        sessions[sessionId]?.termApp = app
    }
    if let ses = event.rawJSON["_iterm_session"] as? String, !ses.isEmpty {
        sessions[sessionId]?.itermSessionId = ses
    }
    if let tty = event.rawJSON["_tty"] as? String, !tty.isEmpty {
        sessions[sessionId]?.ttyPath = tty
    }
    // Extended terminal info (from native bridge binary)
    if let kitty = event.rawJSON["_kitty_window"] as? String, !kitty.isEmpty {
        sessions[sessionId]?.kittyWindowId = kitty
    }
    if let pane = event.rawJSON["_tmux_pane"] as? String, !pane.isEmpty {
        sessions[sessionId]?.tmuxPane = pane
    }
    if let tmuxTty = event.rawJSON["_tmux_client_tty"] as? String, !tmuxTty.isEmpty {
        sessions[sessionId]?.tmuxClientTty = tmuxTty
    }
    if let tmux = event.rawJSON["_tmux"] as? String, !tmux.isEmpty {
        sessions[sessionId]?.tmuxEnv = tmux
    }
    if let bundle = event.rawJSON["_term_bundle"] as? String, !bundle.isEmpty {
        sessions[sessionId]?.termBundleId = bundle
    }
    // Fallback: extract terminal/multiplexer info from _env sub-object (direct plugin format)
    if let env = event.rawJSON["_env"] as? [String: String] {
        applyEnvMetadata(into: &sessions, sessionId: sessionId, env: env)
    }
    applyHookProcessId(into: &sessions, sessionId: sessionId, event: event)
    if let source = SessionSnapshot.normalizedSupportedSource(event.rawJSON["_source"] as? String) {
        sessions[sessionId]?.source = source
    } else if sessions[sessionId]?.source == "claude",
              let path = (event.rawJSON["transcript_path"] as? String)
                ?? (event.rawJSON["transcriptPath"] as? String),
              CursorSessionFolding.isCursorAgentTranscriptPath(path) {
        // Untagged Cursor Agent Task hooks inherit SessionSnapshot's default
        // "claude" — rebrand so merge/hide and the badge follow Cursor.
        sessions[sessionId]?.source = "cursor"
    }
    // cmux surface / workspace (injected by bridge from CMUX_SURFACE_ID / CMUX_WORKSPACE_ID env vars)
    if let surface = event.rawJSON["_cmux_surface_id"] as? String, !surface.isEmpty {
        sessions[sessionId]?.cmuxSurfaceId = surface
    }
    if let workspace = event.rawJSON["_cmux_workspace_id"] as? String, !workspace.isEmpty {
        sessions[sessionId]?.cmuxWorkspaceId = workspace
    }
    // Zellij multiplexer pane / session (injected by bridge from ZELLIJ_* env vars)
    if let zellijPane = event.rawJSON["_zellij_pane_id"] as? String, !zellijPane.isEmpty {
        sessions[sessionId]?.zellijPaneId = zellijPane
    }
    if let zellijSession = event.rawJSON["_zellij_session_name"] as? String, !zellijSession.isEmpty {
        sessions[sessionId]?.zellijSessionName = zellijSession
    }
    // WezTerm / Kaku pane id (injected by bridge from WEZTERM_PANE env var)
    if let weztermPane = event.rawJSON["_wezterm_pane"] as? String, !weztermPane.isEmpty {
        sessions[sessionId]?.weztermPaneId = weztermPane
    }
    applyHerdrRoute(into: &sessions, sessionId: sessionId, event: event)
    // Superset workspace / pane (injected by bridge from SUPERSET_* env vars). Presence routes
    // activation to com.superset.desktop instead of the spoofed kitty TERM_PROGRAM. (#213)
    if let supersetWs = event.rawJSON["_superset_workspace_id"] as? String, !supersetWs.isEmpty {
        sessions[sessionId]?.supersetWorkspaceId = supersetWs
    }
    if let supersetPane = event.rawJSON["_superset_pane_id"] as? String, !supersetPane.isEmpty {
        sessions[sessionId]?.supersetPaneId = supersetPane
    }
    // Orca terminal handle / worktree (injected by bridge from ORCA_* env vars).
    // Presence routes activation to com.stablyai.orca and drives a per-terminal
    // `orca terminal switch`, which is what makes several worktrees of one repo
    // distinguishable (#302).
    if let orcaHandle = event.rawJSON["_orca_terminal_handle"] as? String, !orcaHandle.isEmpty {
        sessions[sessionId]?.orcaTerminalHandle = orcaHandle
    }
    if let orcaWorktree = event.rawJSON["_orca_worktree_id"] as? String, !orcaWorktree.isEmpty {
        sessions[sessionId]?.orcaWorktreeId = orcaWorktree
    }
    // Claude Desktop Code-tab session id (injected by bridge from
    // CLAUDE_CODE_HOST_SESSION_ID).
    if let hostId = claudeDesktopSessionId(in: event) {
        sessions[sessionId]?.claudeDesktopSessionId = hostId
    }
    if let remoteHostId = event.rawJSON["_remote_host_id"] as? String, !remoteHostId.isEmpty {
        sessions[sessionId]?.remoteHostId = remoteHostId
    }
    if let remoteHostName = event.rawJSON["_remote_host_name"] as? String, !remoteHostName.isEmpty {
        sessions[sessionId]?.remoteHostName = remoteHostName
    }
    if let providerSessionId = event.rawJSON["session_id"] as? String,
       !providerSessionId.isEmpty,
       sessions[sessionId]?.isRemote == true
            || (sessions[sessionId]?.source == "codex"
                && sessions[sessionId]?.termBundleId == "com.openai.codex") {
        let isCodexDesktop = sessions[sessionId]?.source == "codex"
            && sessions[sessionId]?.termBundleId == "com.openai.codex"
        sessions[sessionId]?.providerSessionId = isCodexDesktop
            ? normalizedCodexDesktopProviderSessionId(providerSessionId)
            : providerSessionId
    }
    if let sessionTitle = event.rawJSON["session_title"] as? String,
       !sessionTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
        sessions[sessionId]?.sessionTitle = sessionTitle
    }
    if let parentSessionId = SubsessionRouter.parentCardId(in: event.rawJSON) {
        sessions[sessionId]?.parentSessionId = parentSessionId
    }
}

private func normalizedCodexDesktopProviderSessionId(_ sessionId: String) -> String {
    let prefix = "codexapp:"
    guard sessionId.hasPrefix(prefix) else { return sessionId }
    return String(sessionId.dropFirst(prefix.count))
}

/// Pull a non-empty string from a hook JSON value.
/// Supports plain strings and content-part arrays such as Kimi Code CLI's
/// `prompt: [{ "type": "text", "text": "..." }]`.
private func stringFromHookJSONValue(_ value: Any?) -> String? {
    if let value = value as? String {
        // Trim only to detect empty / whitespace-only payloads; return the
        // original value so callers preserve any leading/trailing
        // whitespace inside code-snippet prompts and multi-line content.
        return value.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty
            ? nil : value
    }

    let parts: [[String: Any]]
    if let typed = value as? [[String: Any]] {
        parts = typed
    } else if let anyParts = value as? [Any] {
        parts = anyParts.compactMap { $0 as? [String: Any] }
        if parts.isEmpty { return nil }
    } else {
        return nil
    }

    let texts = parts.compactMap { part -> String? in
        if let type = part["type"] as? String, type != "text" { return nil }
        guard let text = part["text"] as? String,
              !text.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty else {
            return nil
        }
        return text
    }
    let joined = texts.joined()
    return joined.isEmpty ? nil : joined
}

/// The model a hook names: top-level `model`, or Hermes's `extra.model`.
private func hookReportedModel(_ event: HookEvent) -> String? {
    if let model = event.rawJSON["model"] as? String, !model.isEmpty { return model }
    return HermesHookPayload.model(in: event.rawJSON)
}

private func firstStringFromDict(_ dict: [String: Any], keys: [String]) -> String? {
    for key in keys {
        if let value = stringFromHookJSONValue(dict[key]) {
            return value
        }
    }
    return nil
}

/// Lowercased `notification_type` for a Notification event, if it carries one.
/// CodeBuddy documents `permission_prompt` / `idle_prompt` / `auth_success`;
/// other CLIs either omit the field or use the same spellings. (#290)
public func notificationKind(from event: HookEvent) -> String? {
    guard let raw = firstStringFromEvent(
        event,
        keys: ["notification_type", "notificationType"],
        includeNested: true
    ) else { return nil }
    let trimmed = raw.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).lowercased()
    return trimmed.isEmpty ? nil : trimmed
}

private func firstStringFromEvent(_ event: HookEvent, keys: [String], includeNested: Bool) -> String? {
    if let value = firstStringFromDict(event.rawJSON, keys: keys) {
        return value
    }
    if includeNested {
        // "extra" is Hermes's envelope for everything beyond the four common
        // hook fields — assistant_response and friends live there (#303).
        for containerKey in ["payload", "data", "extra"] {
            if let nested = event.rawJSON[containerKey] as? [String: Any],
               let value = firstStringFromDict(nested, keys: keys) {
                return value
            }
        }
    }
    return nil
}

private func subagentType(from event: HookEvent) -> String {
    firstStringFromEvent(event, keys: ["agent_type", "agentType"], includeNested: false) ?? "Agent"
}

private func ensureSubagent(
    sessions: inout [String: SessionSnapshot],
    sessionId: String,
    agentId: String,
    event: HookEvent
) -> Bool {
    // Only SubagentStart/SessionStart may reopen a closed agent id for most
    // providers. Cursor Tasks relaunch via UserPromptSubmit (see handleSubagentEvent).
    // Later tool/response hooks with the same agent_id must not revive it.
    if sessions[sessionId]?.hasClosedSubagentId(agentId) == true {
        return false
    }
    if sessions[sessionId]?.subagents[agentId] == nil {
        sessions[sessionId]?.subagents[agentId] = SubagentState(
            agentId: agentId,
            agentType: subagentType(from: event)
        )
    }
    return true
}

/// Keep a child's own `model` (Codex child threads report it on their hooks)
/// on its SubagentState. The parent's model is never used as a stand-in —
/// `extractMetadata` is skipped for subagent events for the same reason.
private func recordSubagentModel(
    sessions: inout [String: SessionSnapshot],
    sessionId: String,
    agentId: String,
    event: HookEvent
) {
    guard sessions[sessionId]?.subagents[agentId] != nil,
          let model = (event.rawJSON["model"] as? String)?
              .trimmingCharacters(in: .whitespacesAndNewlines),
          !model.isEmpty else { return }
    sessions[sessionId]?.subagents[agentId]?.model = model
}

/// Mark the row of a child session Agent Sub-Sessions folded into this card
/// (``SubagentState/subsessionKind``), so the child's later hooks follow it
/// here. A row the agent's own SubagentStart rebuilt is marked again by the
/// child's next folded hook.
private func recordFoldedSubsession(
    sessions: inout [String: SessionSnapshot],
    sessionId: String,
    agentId: String,
    event: HookEvent
) {
    guard let kind = SubsessionRouter.foldedKind(of: event),
          sessions[sessionId]?.subagents[agentId] != nil else { return }
    sessions[sessionId]?.subagents[agentId]?.subsessionKind = kind
}

/// Handle subagent events. Returns true if the event was consumed.
private func handleSubagentEvent(
    sessions: inout [String: SessionSnapshot],
    sessionId: String,
    agentId: String,
    eventName: String,
    event: HookEvent,
    maxHistory: Int,
    effects: inout [SideEffect]
) -> Bool {
    switch eventName {
    case "SubagentStart", "SessionStart":
        let agentType = subagentType(from: event)
        sessions[sessionId]?.clearClosedSubagentId(agentId)
        sessions[sessionId]?.subagents[agentId] = SubagentState(
            agentId: agentId,
            agentType: agentType
        )
        // Subagent spawned — parent session is actively processing
        if sessions[sessionId]?.status == .idle || sessions[sessionId]?.status == .processing {
            sessions[sessionId]?.status = .running
            sessions[sessionId]?.currentTool = "Agent"
            sessions[sessionId]?.toolDescription = agentType
        }
        sessions[sessionId]?.lastActivity = Date()
        effects.append(.setActiveSession(sessionId: sessionId))
        return true

    case "UserPromptSubmit":
        // Cursor has no SessionStart for Tasks; beforeSubmitPrompt is the relaunch signal.
        if shouldReopenSubagentOnPrompt(event: event, session: sessions[sessionId]) {
            sessions[sessionId]?.clearClosedSubagentId(agentId)
        }
        guard ensureSubagent(sessions: &sessions, sessionId: sessionId, agentId: agentId, event: event) else {
            return true
        }
        sessions[sessionId]?.subagents[agentId]?.status = .processing
        sessions[sessionId]?.subagents[agentId]?.lastActivity = Date()
        // Cursor merge-into-main only: keep parent chat text live for folded Tasks
        // (and for main-chat hooks incorrectly tagged with agent_id). Do not apply
        // to Codex/plugin children — their prompts must not overwrite the parent card.
        if shouldSurfaceCursorSubagentChat(event: event, session: sessions[sessionId]),
           let prompt = firstStringFromEvent(
               event,
               keys: ["prompt", "user_prompt", "userPrompt"],
               includeNested: true
           ) {
            sessions[sessionId]?.lastUserPrompt = prompt
            if sessions[sessionId]?.recentMessages.last?.isUser == true {
                sessions[sessionId]?.recentMessages.removeLast()
            }
            sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: true, text: prompt))
        }
        if sessions[sessionId]?.status != .waitingApproval && sessions[sessionId]?.status != .waitingQuestion {
            let agentType = sessions[sessionId]?.subagents[agentId]?.agentType
            sessions[sessionId]?.status = .running
            sessions[sessionId]?.currentTool = "Agent"
            sessions[sessionId]?.toolDescription = agentType
        }
        sessions[sessionId]?.lastActivity = Date()
        effects.append(.setActiveSession(sessionId: sessionId))
        return true

    case "SubagentStop", "Stop", "SessionEnd":
        sessions[sessionId]?.subagents.removeValue(forKey: agentId)
        // Codex fires SubagentStop at the end of every child *turn*, and its
        // agent_id is the child's thread id, reused for follow-up turns sent
        // via send_message / followup_task without a new SubagentStart. A
        // tombstone here would drop those turns' hooks (ensureSubagent) and
        // auto-deny their PermissionRequests (shouldSuppressClosedSubagentUI).
        // Removing the entry is enough: Codex awaits each hook in order, so no
        // stale tool hook can trail the stop, and the next turn's hooks
        // recreate the entry.
        if !(eventName == "SubagentStop" && isCodexSubagentEvent(event, session: sessions[sessionId])) {
            sessions[sessionId]?.recordClosedSubagentId(agentId)
        }
        // If no more subagents, revert parent to processing (waiting for main thread to continue)
        if sessions[sessionId]?.subagents.isEmpty == true {
            if sessions[sessionId]?.status == .running && sessions[sessionId]?.currentTool == "Agent" {
                sessions[sessionId]?.status = .processing
                sessions[sessionId]?.currentTool = nil
                sessions[sessionId]?.toolDescription = nil
            }
        }
        sessions[sessionId]?.lastActivity = Date()
        return true

    case "PreToolUse":
        guard ensureSubagent(sessions: &sessions, sessionId: sessionId, agentId: agentId, event: event) else {
            return true
        }
        sessions[sessionId]?.subagents[agentId]?.status = .running
        sessions[sessionId]?.subagents[agentId]?.currentTool = event.activityLabel
        sessions[sessionId]?.subagents[agentId]?.currentToolUseId = event.toolUseId
        sessions[sessionId]?.subagents[agentId]?.toolDescription = event.toolDescription
        sessions[sessionId]?.subagents[agentId]?.lastActivity = Date()
        // Keep parent session showing as active while subagents work
        if sessions[sessionId]?.status != .waitingApproval && sessions[sessionId]?.status != .waitingQuestion {
            sessions[sessionId]?.status = .running
        }
        sessions[sessionId]?.lastActivity = Date()
        return true

    case "PostToolUse":
        guard ensureSubagent(sessions: &sessions, sessionId: sessionId, agentId: agentId, event: event) else {
            return true
        }
        let agentType = sessions[sessionId]?.subagents[agentId]?.agentType
        if sessions[sessionId]?.subagents[agentId]?.finishesAnotherToolUse(event) == true {
            // An earlier tool's step, overtaken by the next tool's start.
            if let tool = event.activityLabel {
                sessions[sessionId]?.recordTool(tool, description: event.toolDescription, success: true, agentType: agentType, maxHistory: maxHistory)
            }
            sessions[sessionId]?.subagents[agentId]?.lastActivity = Date()
            sessions[sessionId]?.lastActivity = Date()
            return true
        }
        if let tool = sessions[sessionId]?.subagents[agentId]?.currentTool {
            let desc = sessions[sessionId]?.subagents[agentId]?.toolDescription
            sessions[sessionId]?.recordTool(tool, description: desc, success: true, agentType: agentType, maxHistory: maxHistory)
        }
        sessions[sessionId]?.subagents[agentId]?.status = .processing
        sessions[sessionId]?.subagents[agentId]?.currentTool = nil
        sessions[sessionId]?.subagents[agentId]?.toolDescription = nil
        sessions[sessionId]?.subagents[agentId]?.lastActivity = Date()
        sessions[sessionId]?.lastActivity = Date()
        return true

    case "PostToolUseFailure":
        guard ensureSubagent(sessions: &sessions, sessionId: sessionId, agentId: agentId, event: event) else {
            return true
        }
        let agentType = sessions[sessionId]?.subagents[agentId]?.agentType
        if sessions[sessionId]?.subagents[agentId]?.finishesAnotherToolUse(event) == true {
            // An earlier tool's step, overtaken by the next tool's start.
            if let tool = event.activityLabel {
                sessions[sessionId]?.recordTool(tool, description: event.toolDescription, success: false, agentType: agentType, maxHistory: maxHistory)
            }
            sessions[sessionId]?.lastActivity = Date()
            return true
        }
        if let tool = sessions[sessionId]?.subagents[agentId]?.currentTool {
            let desc = sessions[sessionId]?.subagents[agentId]?.toolDescription
            sessions[sessionId]?.recordTool(tool, description: desc, success: false, agentType: agentType, maxHistory: maxHistory)
        }
        sessions[sessionId]?.subagents[agentId]?.status = .processing
        sessions[sessionId]?.subagents[agentId]?.currentTool = nil
        sessions[sessionId]?.subagents[agentId]?.toolDescription = nil
        sessions[sessionId]?.lastActivity = Date()
        return true

    case "AfterAgentResponse":
        // Merged Cursor Task events arrive with parent session_id + child agent_id.
        guard ensureSubagent(sessions: &sessions, sessionId: sessionId, agentId: agentId, event: event) else {
            return true
        }
        // Cursor-only: surface the folded reply on the parent card, but never
        // enqueue parent-turn completion from a Task response.
        if shouldSurfaceCursorSubagentChat(event: event, session: sessions[sessionId]),
           let text = firstStringFromEvent(
               event,
               keys: ["text", "message"],
               includeNested: true
           ),
           !text.isEmpty {
            sessions[sessionId]?.lastAssistantMessage = text
            sessions[sessionId]?.addRecentMessage(ChatMessage(isUser: false, text: text))
        }
        sessions[sessionId]?.subagents[agentId]?.status = .processing
        sessions[sessionId]?.subagents[agentId]?.lastActivity = Date()
        sessions[sessionId]?.lastActivity = Date()
        if sessions[sessionId]?.status != .waitingApproval
            && sessions[sessionId]?.status != .waitingQuestion
            && sessions[sessionId]?.status != .running {
            sessions[sessionId]?.status = .processing
        }
        return true

    case "Notification":
        // Keep folded Tasks' ask/question notifications on the parent card.
        // Swallowing them here (as AfterAgentResponse did) dropped waitingQuestion.
        guard ensureSubagent(sessions: &sessions, sessionId: sessionId, agentId: agentId, event: event) else {
            return true
        }
        sessions[sessionId]?.subagents[agentId]?.lastActivity = Date()
        sessions[sessionId]?.lastActivity = Date()
        let notificationText = firstStringFromEvent(
            event,
            keys: ["message", "text", "summary", "status", "detail"],
            includeNested: true
        )
        if let msg = notificationText, !msg.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty {
            sessions[sessionId]?.toolDescription = msg
            sessions[sessionId]?.subagents[agentId]?.toolDescription = msg
        }
        if QuestionPayload.from(event: event) != nil {
            sessions[sessionId]?.status = .waitingQuestion
            sessions[sessionId]?.subagents[agentId]?.status = .waitingQuestion
            effects.append(.setActiveSession(sessionId: sessionId))
        } else if sessions[sessionId]?.status != .waitingApproval
            && sessions[sessionId]?.status != .waitingQuestion
            && sessions[sessionId]?.status != .running {
            sessions[sessionId]?.status = .processing
            sessions[sessionId]?.subagents[agentId]?.status = .processing
        }
        return true

    case "PreCompact", "PostCompact":
        // A subagent compacts its own context, not the parent's: the parent
        // card must not read "Compacting" (or leave a waiting state) for it.
        if sessions[sessionId]?.subagents[agentId] != nil {
            sessions[sessionId]?.subagents[agentId]?.lastActivity = Date()
            sessions[sessionId]?.lastActivity = Date()
        }
        return true

    default:
        return false  // Fall through to normal session handling
    }
}

